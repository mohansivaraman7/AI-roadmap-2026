import json
import sys
from pathlib import Path

import pytest
import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from travel_crew import tools as tools_mod  # noqa: E402
from travel_crew.agents import ReActAgent, parse_json_reply  # noqa: E402
from travel_crew.crew import TravelCrew  # noqa: E402
from travel_crew.tools import Tool, build_toolbox, calculator, currency_convert  # noqa: E402


# ---------- fakes ----------
def fake_toolbox():
    box = build_toolbox()
    canned = {
        "geocode": "Munnar, Kerala, India | lat 10.08, lon 77.06",
        "wikipedia": "Wikipedia — Munnar: a hill station known for tea estates.",
        "weather_forecast": "7-day forecast for Munnar: 2026-10-12: light rain, 15–24 °C, rain chance 70%",
        "currency_convert": "100.00 USD = 8,400.00 INR",
    }
    for name, text in canned.items():
        box[name] = Tool(name, box[name].description, lambda _arg, t=text: t)
    return box


class CrewLLM:
    """Plays every role in the crew by looking at the prompt it receives."""

    def __init__(self):
        self.prompts = []

    def chat(self, messages, max_tokens=None, temperature=None):
        system = messages[0]["content"]
        self.prompts.append(messages[-1]["content"])
        observed = sum(1 for m in messages if m["content"].startswith("Observation:"))
        if "Supervisor" in system:
            return json.dumps({"assignments": [
                {"agent": "researcher", "task": "Research Munnar"},
                {"agent": "weather", "task": "Forecast for Munnar"},
                {"agent": "budget", "task": "Budget for 2 people, 3 days"}]})
        if "Itinerary Writer" in system:
            return "## Overview\nA 3-day Munnar plan."
        if "Destination Researcher" in system:
            return (json.dumps({"thought": "look it up", "action": "wikipedia", "action_input": "Munnar"})
                    if observed == 0 else json.dumps({"final_answer": "Tea estates. (wikipedia)"}))
        if "Weather Analyst" in system:
            return ('Sure! ```json\n{"thought": "check", "action": "weather_forecast", "action_input": "Munnar"}\n```'
                    if observed == 0 else '{"final_answer": "Rain likely {pack umbrella}"}')
        if "Budget Planner" in system:
            if observed == 0:
                return json.dumps({"action": "calculator", "action_input": "2 * 3 * 2500"})
            return json.dumps({"final_answer": "Stay: 15,000 INR"})
        raise AssertionError("unexpected prompt")


# ---------- tools ----------
def test_calculator():
    assert calculator("2 * 3 * 2,500") == "2 * 3 * 2,500 = 15,000"
    with pytest.raises(ValueError):
        calculator("__import__('os')")


def test_currency_same_and_bad_format():
    assert currency_convert("50 inr to INR") == "50.00 INR = 50.00 INR"
    assert "Format" in currency_convert("convert some money")


def test_tool_reports_network_errors(monkeypatch):
    def offline(*a, **k):
        raise requests.ConnectionError("offline")
    monkeypatch.setattr(tools_mod._session, "get", offline)
    out = build_toolbox()["weather_forecast"].run("Munnar")
    assert out.startswith("Tool error") and "weather_forecast" in out


def test_weather_tool_formats_api_response(monkeypatch):
    responses = iter([
        {"results": [{"name": "Munnar", "country": "India", "latitude": 10.08, "longitude": 77.06}]},
        {"daily": {"time": ["2026-10-12"], "weather_code": [61], "temperature_2m_max": [24],
                   "temperature_2m_min": [15], "precipitation_probability_max": [70]}},
    ])

    class Resp:
        def __init__(self, data):
            self.data = data

        def raise_for_status(self):
            pass

        def json(self):
            return self.data

    monkeypatch.setattr(tools_mod._session, "get", lambda *a, **k: Resp(next(responses)))
    out = tools_mod.weather_forecast("Munnar")
    assert "light rain" in out and "15–24 °C" in out and "70%" in out


# ---------- agents ----------
def test_parse_json_reply_handles_fences_and_braces():
    assert parse_json_reply('text ```json\n{"a": "x {y}"}\n```') == {"a": "x {y}"}
    assert parse_json_reply("no json here") is None


def test_react_agent_uses_tool_then_answers():
    llm = CrewLLM()
    agent = ReActAgent("researcher", "Destination Researcher", "🧭", "role", [fake_toolbox()["wikipedia"]], llm)
    events = list(agent.run("Research Munnar"))
    assert [e.kind for e in events] == ["tool", "report"]
    assert "tea estates" in events[0].content
    assert llm.prompts[-1].startswith("Observation: Wikipedia")


def test_react_agent_unknown_tool_and_budget_exhaustion():
    class Stubborn:
        def chat(self, messages, **k):
            return json.dumps({"action": "teleport", "action_input": "Mars"})
    events = list(ReActAgent("x", "X", "?", "r", [], Stubborn(), max_steps=2).run("go"))
    assert "Unknown tool" in events[0].content
    assert events[-1].kind == "report" and "could not complete" in events[-1].content


# ---------- crew ----------
def test_full_crew_run():
    llm = CrewLLM()
    crew = TravelCrew(llm, toolbox=fake_toolbox())
    events = list(crew.run("3 days in Munnar for 2", enabled=["researcher", "weather", "budget"]))
    kinds = [e.kind for e in events]
    assert kinds[0] == "plan" and kinds[-1] == "final"
    assert kinds.count("report") == 3 and kinds.count("tool") == 3
    assert "15,000" in events[kinds.index("tool", 4)].content or any("15,000" in e.content for e in events)
    assert "Tea estates" in llm.prompts[-1]  # writer received the researcher's report


def test_crew_respects_disabled_agents_and_direct_answers():
    class Chatty:
        def chat(self, messages, **k):
            return '{"direct_answer": "Hello! Where would you like to go?"}'
    crew = TravelCrew(Chatty(), toolbox=fake_toolbox())
    assert list(crew.run("hi"))[0].content.startswith("Hello")
    assert "at least one agent" in list(crew.run("trip", enabled=[]))[0].content

    llm = CrewLLM()
    events = list(TravelCrew(llm, toolbox=fake_toolbox()).run("trip", enabled=["weather"]))
    assert all("Budget" not in e.title for e in events)
