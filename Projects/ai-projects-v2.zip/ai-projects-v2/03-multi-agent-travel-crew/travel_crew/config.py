"""Central configuration. Every value can be overridden with an environment variable or a .env file."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    # Hugging Face
    hf_token: str = os.getenv("HF_TOKEN", "")
    llm_model: str = os.getenv("LLM_MODEL", "Qwen/Qwen2.5-72B-Instruct")
    llm_provider: str = os.getenv("LLM_PROVIDER", "")
    max_new_tokens: int = _int("MAX_NEW_TOKENS", 900)
    temperature: float = _float("TEMPERATURE", 0.3)

    # Agents
    max_agent_steps: int = _int("MAX_AGENT_STEPS", 4)
    http_timeout_sec: int = _int("HTTP_TIMEOUT_SEC", 12)

    # Free, key-less public APIs used as tools
    geocoding_url: str = os.getenv("GEOCODING_URL", "https://geocoding-api.open-meteo.com/v1/search")
    forecast_url: str = os.getenv("FORECAST_URL", "https://api.open-meteo.com/v1/forecast")
    wikipedia_api: str = os.getenv("WIKIPEDIA_API", "https://en.wikipedia.org/w/api.php")
    fx_url: str = os.getenv("FX_URL", "https://api.frankfurter.app/latest")

    # Server
    host: str = os.getenv("GRADIO_SERVER_NAME", "0.0.0.0")
    port: int = _int("GRADIO_SERVER_PORT", 7860)


settings = Settings()
