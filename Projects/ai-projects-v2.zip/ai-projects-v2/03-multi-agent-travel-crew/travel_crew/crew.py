"""The crew: a Supervisor delegates to specialist agents, then a Writer agent merges their reports."""
import logging
from typing import Dict, Iterator, List, Optional

from .agents import CrewEvent, ReActAgent, parse_json_reply
from .tools import Tool, build_toolbox

logger = logging.getLogger(__name__)

SPECIALISTS = {
    "researcher": ("Destination Researcher", "🧭",
                   "You find what a traveller should know: where the place is, highlights, culture, "
                   "local tips and the best areas to stay.", ["geocode", "wikipedia"]),
    "weather": ("Weather Analyst", "🌦️",
                "You check the live forecast and turn it into packing and scheduling advice "
                "(which days suit outdoor plans).", ["weather_forecast"]),
    "budget": ("Budget Planner", "💰",
               "You estimate a realistic budget (stay, food, local transport, activities) and convert it "
               "into the traveller's home currency with live rates. Show the arithmetic.",
               ["currency_convert", "calculator"]),
}

SUPERVISOR_PROMPT = """You are the Supervisor of a travel-planning team.
Team members:
{roster}

The traveller's home currency is {currency}.
Conversation so far:
{history}

New request: {request}

Decide which team members are needed and give each a precise, self-contained task (include the
destination, dates/duration, number of travellers and budget if known).
If the request is small talk or not about travel, answer it yourself.
Reply with JSON only, either:
{{"assignments": [{{"agent": "researcher", "task": "..."}}, {{"agent": "weather", "task": "..."}}]}}
or
{{"direct_answer": "..."}}"""

WRITER_PROMPT = """You are the Itinerary Writer. Merge the specialists' reports into one clear travel plan.
Request: {request}
Home currency: {currency}

Specialist reports:
{reports}

Write in Markdown with these sections when relevant: **Overview**, **Day-by-day plan**, **Weather & packing**,
**Budget** (a small table), **Tips**. Use only facts from the reports — if something is missing, say so
briefly instead of inventing it. Keep it under 450 words."""


def _history_text(history: List[dict], max_turns: int = 6) -> str:
    lines = [f"{m['role']}: {m['content'][:400]}" for m in history[-max_turns:]
             if isinstance(m.get("content"), str) and not (m.get("metadata") or {}).get("title")]
    return "\n".join(lines) or "(none)"


class TravelCrew:
    def __init__(self, llm, max_agent_steps: int = 4, toolbox: Optional[Dict[str, Tool]] = None):
        self.llm = llm
        toolbox = toolbox or build_toolbox()
        self.agents: Dict[str, ReActAgent] = {
            key: ReActAgent(key, name, icon, role, [toolbox[t] for t in tools], llm, max_agent_steps)
            for key, (name, icon, role, tools) in SPECIALISTS.items()
        }

    def roster(self, enabled: List[str]) -> str:
        return "\n".join(f"- {key}: {a.name} — {a.role}" for key, a in self.agents.items() if key in enabled)

    def plan(self, request: str, history: List[dict], enabled: List[str], currency: str) -> dict:
        raw = self.llm.chat([{"role": "user", "content": SUPERVISOR_PROMPT.format(
            roster=self.roster(enabled), currency=currency, history=_history_text(history), request=request)}],
            max_tokens=500, temperature=0.0)
        data = parse_json_reply(raw) or {}
        if data.get("direct_answer") and not data.get("assignments"):
            return {"direct_answer": str(data["direct_answer"])}
        assignments = [a for a in data.get("assignments") or []
                       if isinstance(a, dict) and a.get("agent") in enabled and a.get("task")]
        if not assignments:  # fallback: everyone works on the raw request
            assignments = [{"agent": key, "task": request} for key in enabled]
        return {"assignments": assignments}

    def run(self, request: str, history: Optional[List[dict]] = None,
            enabled: Optional[List[str]] = None, currency: str = "INR") -> Iterator[CrewEvent]:
        history = history or []
        enabled = [k for k in (list(self.agents) if enabled is None else enabled) if k in self.agents]
        if not enabled:
            yield CrewEvent("final", "Answer", "Enable at least one agent in the side panel.")
            return

        decision = self.plan(request, history, enabled, currency)
        if "direct_answer" in decision:
            yield CrewEvent("final", "Answer", decision["direct_answer"])
            return

        plan_md = "\n".join(f"- {self.agents[a['agent']].icon} **{self.agents[a['agent']].name}**: {a['task']}"
                            for a in decision["assignments"])
        yield CrewEvent("plan", "🧑‍✈️ Supervisor · delegation plan", plan_md)

        reports: List[str] = []
        for assignment in decision["assignments"]:
            agent = self.agents[assignment["agent"]]
            context = "\n\n".join(reports)
            for event in agent.run(f"{assignment['task']} (Traveller's home currency: {currency})", context):
                yield event
                if event.kind == "report":
                    reports.append(f"### {agent.name}\n{event.content}")

        final = self.llm.chat([{"role": "user", "content": WRITER_PROMPT.format(
            request=request, currency=currency, reports="\n\n".join(reports))}])
        yield CrewEvent("final", "Answer", final)
