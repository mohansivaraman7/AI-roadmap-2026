"""Real tools the agents can call. All use free public APIs that need no API key."""
import ast
import logging
import operator
import re
from dataclasses import dataclass
from typing import Callable, Dict

import requests

from .config import settings

logger = logging.getLogger(__name__)

_session = requests.Session()
_session.headers.update({"User-Agent": "travel-crew-demo/1.0 (educational project)"})

WEATHER_CODES = {0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast", 45: "fog",
                 48: "fog", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle", 61: "light rain",
                 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow", 75: "heavy snow",
                 80: "rain showers", 81: "rain showers", 82: "violent showers", 95: "thunderstorm",
                 96: "thunderstorm with hail", 99: "thunderstorm with hail"}


@dataclass
class Tool:
    name: str
    description: str
    func: Callable[[str], str]

    def run(self, arg: str) -> str:
        try:
            return self.func(str(arg).strip())
        except requests.RequestException as exc:
            logger.warning("%s network error: %s", self.name, exc)
            return f"Tool error: could not reach the {self.name} service ({exc.__class__.__name__})."
        except Exception as exc:
            return f"Tool error: {exc}"


def _get(url: str, params: dict) -> dict:
    resp = _session.get(url, params=params, timeout=settings.http_timeout_sec)
    resp.raise_for_status()
    return resp.json()


def _locate(place: str) -> dict:
    data = _get(settings.geocoding_url, {"name": place, "count": 1, "language": "en", "format": "json"})
    results = data.get("results") or []
    if not results:
        raise ValueError(f"No location found for '{place}'. Try just the city name.")
    return results[0]


def geocode(place: str) -> str:
    loc = _locate(place)
    return (f"{loc['name']}, {loc.get('admin1', '')}, {loc.get('country', '')} | lat {loc['latitude']}, "
            f"lon {loc['longitude']} | timezone {loc.get('timezone', '?')} | "
            f"population {loc.get('population', 'unknown')} | elevation {loc.get('elevation', '?')} m")


def weather_forecast(place: str) -> str:
    loc = _locate(place)
    data = _get(settings.forecast_url, {
        "latitude": loc["latitude"], "longitude": loc["longitude"], "timezone": "auto", "forecast_days": 7,
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"})
    d = data["daily"]
    lines = [f"7-day forecast for {loc['name']}, {loc.get('country', '')}:"]
    for i, day in enumerate(d["time"]):
        lines.append(f"{day}: {WEATHER_CODES.get(d['weather_code'][i], 'mixed')}, "
                     f"{d['temperature_2m_min'][i]}–{d['temperature_2m_max'][i]} °C, "
                     f"rain chance {d['precipitation_probability_max'][i]}%")
    return "\n".join(lines)


def wikipedia_summary(topic: str) -> str:
    hits = _get(settings.wikipedia_api, {"action": "opensearch", "search": topic, "limit": 1,
                                         "namespace": 0, "format": "json"})
    if not hits or not hits[1]:
        return f"No Wikipedia article found for '{topic}'."
    title = hits[1][0]
    data = _get(settings.wikipedia_api, {"action": "query", "prop": "extracts", "exintro": 1,
                                         "explaintext": 1, "redirects": 1, "titles": title, "format": "json"})
    page = next(iter(data["query"]["pages"].values()))
    extract = re.sub(r"\s+", " ", page.get("extract", "")).strip()
    return f"Wikipedia — {title}: {extract[:1500]}" if extract else f"No summary for '{title}'."


_FX_RE = re.compile(r"([\d,.]+)\s*([A-Za-z]{3})\s*(?:to|in|->|=)\s*([A-Za-z]{3})", re.IGNORECASE)


def currency_convert(query: str) -> str:
    match = _FX_RE.search(query)
    if not match:
        return "Format must be like '1500 USD to INR'."
    amount, src, dst = float(match.group(1).replace(",", "")), match.group(2).upper(), match.group(3).upper()
    if src == dst:
        return f"{amount:,.2f} {src} = {amount:,.2f} {dst}"
    data = _get(settings.fx_url, {"amount": amount, "from": src, "to": dst})
    value = data["rates"][dst]
    return f"{amount:,.2f} {src} = {value:,.2f} {dst} (ECB reference rate, {data.get('date', 'latest')})"


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow,
        ast.USub: operator.neg, ast.UAdd: operator.pos}


def _eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        if isinstance(node.op, ast.Pow) and abs(_eval(node.right)) > 10:
            raise ValueError("exponent too large")
        return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    raise ValueError("only numbers and + - * / // % ** ( ) are allowed")


def calculator(expression: str) -> str:
    expr = expression.replace(",", "").replace("x", "*").replace("×", "*")
    result = _eval(ast.parse(expr, mode="eval").body)
    return f"{expression} = {round(result, 2):,}"


def build_toolbox() -> Dict[str, Tool]:
    tools = [
        Tool("geocode", "Find a place: country, region, coordinates, timezone, population. Input: place name.",
             geocode),
        Tool("weather_forecast", "Live 7-day weather forecast for a city. Input: city name.", weather_forecast),
        Tool("wikipedia", "Background facts about a place, landmark or culture. Input: search topic.",
             wikipedia_summary),
        Tool("currency_convert", "Live exchange rate conversion. Input like '1500 USD to INR'.",
             currency_convert),
        Tool("calculator", "Exact arithmetic. Input: expression like '3 * 4500 + 2 * 1200'.", calculator),
    ]
    return {t.name: t for t in tools}
