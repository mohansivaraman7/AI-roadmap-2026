"""A small, dependency-free ReAct agent: think → call a tool → observe → repeat → final answer."""
import json
import logging
import re
from dataclasses import dataclass
from typing import Dict, Iterator, List, Optional

from .tools import Tool

logger = logging.getLogger(__name__)

REACT_SYSTEM = """You are the {name} in a travel-planning team. {role}

Tools you can use:
{tools}

Reply on EVERY turn with exactly ONE JSON object and nothing else.
To use a tool:   {{"thought": "why", "action": "<tool name>", "action_input": "<text input>"}}
When finished:   {{"thought": "why", "final_answer": "<your report in Markdown>"}}

Rules: use tools for facts, numbers, prices and weather — never guess them. Use at most {max_steps} tool
calls. Keep the final report short and factual (bullet points), and mention which tool each fact came from."""


@dataclass
class CrewEvent:
    kind: str      # plan | tool | report | final | info
    title: str
    content: str = ""


def parse_json_reply(text: str) -> Optional[dict]:
    """Return the first valid JSON object found in the model's reply (tolerates prose and code fences)."""
    text = re.sub(r"```(?:json)?", "", text or "")
    decoder = json.JSONDecoder()
    start = text.find("{")
    while start != -1:
        try:
            obj, _ = decoder.raw_decode(text, start)
            if isinstance(obj, dict):
                return obj
        except json.JSONDecodeError:
            pass
        start = text.find("{", start + 1)
    return None


class ReActAgent:
    def __init__(self, key: str, name: str, icon: str, role: str, tools: List[Tool], llm, max_steps: int = 4):
        self.key = key
        self.name = name
        self.icon = icon
        self.role = role
        self.tools: Dict[str, Tool] = {t.name: t for t in tools}
        self.llm = llm
        self.max_steps = max_steps

    def _system_prompt(self) -> str:
        tools = "\n".join(f"- {t.name}: {t.description}" for t in self.tools.values()) or "- (no tools)"
        return REACT_SYSTEM.format(name=self.name, role=self.role, tools=tools, max_steps=self.max_steps)

    def run(self, task: str, context: str = "") -> Iterator[CrewEvent]:
        """Yields tool events and finally one 'report' event holding the agent's answer."""
        known = context or "(nothing yet)"
        messages = [{"role": "system", "content": self._system_prompt()},
                    {"role": "user", "content": f"Task: {task}\n\nWhat the team knows so far:\n{known}"}]
        for _ in range(self.max_steps):
            raw = self.llm.chat(messages)
            data = parse_json_reply(raw)
            if data is None:  # model ignored the format: accept plain text as the answer
                yield CrewEvent("report", f"{self.icon} {self.name} · report", raw.strip())
                return
            if data.get("final_answer"):
                yield CrewEvent("report", f"{self.icon} {self.name} · report", str(data["final_answer"]).strip())
                return
            action, arg = str(data.get("action", "")).strip(), str(data.get("action_input", "")).strip()
            tool = self.tools.get(action)
            observation = tool.run(arg) if tool else (
                f"Unknown tool '{action}'. Available: {', '.join(self.tools) or 'none'}.")
            yield CrewEvent("tool", f"{self.icon} {self.name} → {action or '?'}({arg[:60]})",
                            f"**Thought:** {data.get('thought', '')}\n\n**Observation:**\n```text\n{observation}\n```")
            messages.append({"role": "assistant", "content": raw})
            messages.append({"role": "user", "content": f"Observation: {observation}"})

        messages.append({"role": "user", "content": "Tool budget used up. Reply now with your final_answer JSON."})
        data = parse_json_reply(self.llm.chat(messages)) or {}
        yield CrewEvent("report", f"{self.icon} {self.name} · report",
                        str(data.get("final_answer") or "I could not complete this task with the tools available."))
