"""Multi-Agent Travel Crew — Gradio chat UI. Run: python app.py  → http://localhost:7860"""
import logging

import gradio as gr

from travel_crew.config import settings
from travel_crew.crew import SPECIALISTS, TravelCrew
from travel_crew.llm import HFChatModel, LLMError

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("app")

llm = HFChatModel(settings.llm_model, settings.hf_token, settings.llm_provider,
                  settings.max_new_tokens, settings.temperature)
crew = TravelCrew(llm, settings.max_agent_steps)

AGENT_CHOICES = [(f"{icon} {name}", key) for key, (name, icon, _, _) in SPECIALISTS.items()]
CURRENCIES = ["INR", "USD", "EUR", "GBP", "AUD", "CAD", "SGD", "JPY", "CHF", "AED"]


def chat(message: str, history: list, enabled: list, currency: str):
    message = (message or "").strip()
    if not message:
        yield history, ""
        return
    prior = list(history)
    history = prior + [{"role": "user", "content": message}]
    yield history, ""
    try:
        for event in crew.run(message, prior, enabled, currency):
            if event.kind == "final":
                history.append({"role": "assistant", "content": event.content})
            else:
                history.append({"role": "assistant", "content": event.content,
                                "metadata": {"title": event.title, "status": "done"}})
            yield history, ""
    except LLMError as exc:
        history.append({"role": "assistant", "content": f"⚠️ {exc}"})
        yield history, ""
    except Exception as exc:
        logger.exception("Crew run failed")
        history.append({"role": "assistant", "content": f"⚠️ Something went wrong: {exc}"})
        yield history, ""


def build_ui() -> gr.Blocks:
    roster = "\n".join(f"- {icon} **{name}** — tools: `{'`, `'.join(tools)}`"
                       for name, icon, _, tools in SPECIALISTS.values())
    with gr.Blocks(title="Multi-Agent Travel Crew", theme=gr.themes.Soft()) as demo:
        gr.Markdown("# ✈️ Multi-Agent Travel Crew\n"
                    "A **Supervisor** agent splits your request and delegates to specialist **AI agents**. "
                    "Each agent reasons, calls real tools (live weather, Wikipedia, live FX rates, calculator) "
                    "and reports back; an **Itinerary Writer** merges everything. Expand the grey steps to "
                    "watch the hand-offs.")
        with gr.Row():
            with gr.Column(scale=1, min_width=300):
                enabled = gr.CheckboxGroup(AGENT_CHOICES, value=[k for _, k in AGENT_CHOICES],
                                           label="Agents on duty")
                currency = gr.Dropdown(CURRENCIES, value="INR", label="Home currency")
                gr.Markdown("### The team\n" + roster + "\n- ✍️ **Itinerary Writer** — merges the reports")
            with gr.Column(scale=2):
                chatbot = gr.Chatbot(type="messages", height=620, label="Crew", show_copy_button=True)
                with gr.Row():
                    message = gr.Textbox(placeholder="e.g. Plan 3 days in Munnar for 2 people next week",
                                         scale=5, show_label=False, autofocus=True)
                    send = gr.Button("Plan", variant="primary", scale=1)
                gr.Examples(["Plan a 3-day trip to Munnar for 2 people this week, mid-range budget.",
                             "4 days in Tokyo for a solo traveller — what's the weather and a budget in INR?",
                             "Is this a good week for a beach trip to Goa? What should I pack?",
                             "Weekend in Paris for a couple, budget 1500 EUR — is it enough?"], inputs=message)
                gr.ClearButton([chatbot, message], value="🧹 New chat")

        send.click(chat, [message, chatbot, enabled, currency], [chatbot, message])
        message.submit(chat, [message, chatbot, enabled, currency], [chatbot, message])
    return demo


if __name__ == "__main__":
    build_ui().queue(default_concurrency_limit=4).launch(server_name=settings.host, server_port=settings.port)
