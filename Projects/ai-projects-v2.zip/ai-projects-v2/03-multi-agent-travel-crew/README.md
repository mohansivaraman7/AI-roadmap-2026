# ✈️ Project 3 — Multi-Agent Travel Crew (AI Agents)

A team of AI agents plans trips together. A **Supervisor** reads the request, decides which specialists are
needed and writes each one a task. Every specialist is an independent **ReAct agent** with its own role and
its own tools; it reasons, calls tools, reads the results and reports back. An **Itinerary Writer** merges
the reports into one plan.

| Agent | Tools (all live, free, no API key) |
|---|---|
| 🧑‍✈️ Supervisor | delegates — or answers small talk directly |
| 🧭 Destination Researcher | `geocode` (Open-Meteo), `wikipedia` |
| 🌦️ Weather Analyst | `weather_forecast` (Open-Meteo 7-day) |
| 💰 Budget Planner | `currency_convert` (Frankfurter / ECB rates), `calculator` (safe AST math) |
| ✍️ Itinerary Writer | none — writes only from the agents' reports |

The ReAct loop is written from scratch (`travel_crew/agents.py`, ~100 lines) using a JSON protocol, so it works
with any Hugging Face chat model — no framework, no native function-calling required. Every thought, tool call
and observation appears in the chat as an expandable step. In the side panel you can switch agents off to show
students how the plan changes.

## How a request flows

```
user ──► Supervisor (JSON plan) ──► Researcher ─► tools ─► report ─┐
                                ──► Weather     ─► tools ─► report ─┼─► Writer ──► final itinerary
                                ──► Budget      ─► tools ─► report ─┘
         (each agent sees the earlier agents' reports as shared context)
```

## Project layout

```
app.py                     Gradio UI (entry point)
travel_crew/config.py      All settings (env / .env)
travel_crew/llm.py         Hugging Face chat client with retries
travel_crew/tools.py       Real tools (HTTP + safe calculator)
travel_crew/agents.py      Generic ReAct agent
travel_crew/crew.py        Supervisor, specialists, writer
tests/                     Offline tests (role-playing fake LLM, mocked HTTP)
```

## Run in PyCharm

1. **File → Open** this folder, create a Virtualenv interpreter (Python 3.10–3.12).
2. Terminal: `pip install -r requirements-dev.txt`
3. Copy `.env.example` to `.env`, set `HF_TOKEN`.
4. Right-click `app.py` → **Run** → http://localhost:7860
5. Right-click `tests` → **Run 'pytest in tests'**.

The machine needs internet access to the tool APIs (open-meteo.com, wikipedia.org, frankfurter.app). If one is
blocked, that agent reports the tool error and the writer says the information is missing — nothing crashes.

## Docker

```bash
docker build -t multi-agent-travel-crew .
docker run -p 7863:7860 --env-file .env multi-agent-travel-crew
```

## Jenkins

Same pipeline as the other projects: lint → tests → build → smoke test → optional push / deploy
(default deploy port 7863).

## Settings

| Variable | Default | Effect |
|---|---|---|
| `LLM_MODEL` | `Qwen/Qwen2.5-72B-Instruct` | Bigger models follow the JSON tool protocol more reliably |
| `MAX_AGENT_STEPS` | 4 | Tool-call budget per agent |
| `HTTP_TIMEOUT_SEC` | 12 | Per tool request |
