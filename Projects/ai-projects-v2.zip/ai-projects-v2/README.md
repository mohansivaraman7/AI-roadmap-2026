# AI Projects v2 — RAG · Agentic AI · AI Agents

Three standalone projects, each with a Gradio chat UI, Hugging Face models, Dockerfile, Jenkinsfile and offline
tests. Each folder opens directly in PyCharm as its own project.

| # | Project | Concept taught | Hugging Face usage | Port |
|---|---|---|---|---|
| 1 | [Hybrid RAG Assistant](01-hybrid-rag-assistant) | Hybrid search (FAISS + BM25), RRF fusion, query rewriting, cited answers | Chat LLM + embeddings via Inference API | 7861 |
| 2 | [Agentic Data Analyst](02-agentic-data-analyst) | Autonomous plan → code → execute → self-correct → verify loop | Code LLM | 7862 |
| 3 | [Multi-Agent Travel Crew](03-multi-agent-travel-crew) | Supervisor + specialist ReAct agents with live tools | Chat LLM | 7863 |

## Common standards in all three

- `app.py` entry point · package folder for logic · `tests/` runnable without a token or internet
- All settings in `config.py`, overridable via `.env` (see `.env.example`); no secrets in code
- `HFChatModel` wrapper with retries and a friendly error when `HF_TOKEN` is missing
- Dockerfile: `python:3.11-slim`, non-root user, healthcheck, port 7860
- Jenkinsfile: venv → flake8 → pytest (JUnit + coverage) → docker build → smoke test → optional push/deploy
- flake8 + pytest config in `setup.cfg`

## Quick start (any project)

```bash
cd 01-hybrid-rag-assistant          # or 02-… / 03-…
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                # then put your HF_TOKEN in .env
python app.py                       # http://localhost:7860
pytest
```

Run all three in Docker at once: `docker compose up --build` (ports 7861–7863).

**HF token:** https://huggingface.co/settings/tokens → fine-grained token with *Make calls to Inference
Providers*. Free accounts get a monthly credit; the default models can be changed in each `.env`.
