import json
import sys
from dataclasses import replace
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from data_analyst.agent import DataAnalystAgent, extract_code, extract_json  # noqa: E402
from data_analyst.config import settings  # noqa: E402
from data_analyst.sandbox import UnsafeCodeError, run_code, validate_code  # noqa: E402


class ScriptedLLM:
    """Returns canned replies in order; records prompts for assertions."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []

    def chat(self, messages, max_tokens=None, temperature=None):
        self.prompts.append(messages[-1]["content"])
        return self.replies.pop(0)


@pytest.fixture
def cfg(tmp_path):
    return replace(settings, runs_dir=tmp_path / "runs")


@pytest.mark.parametrize("code", [
    "import os\nos.system('ls')",
    "open('/etc/passwd').read()",
    "df.__class__.__bases__",
    "import subprocess",
    "pd.read_csv('/etc/passwd')",
    "eval('1+1')",
])
def test_validate_blocks_unsafe_code(code):
    with pytest.raises(UnsafeCodeError):
        validate_code(code)


def test_validate_allows_normal_analysis():
    validate_code("import numpy as np\nfrom collections import Counter\nprint(df.groupby('region').revenue.sum())")


def test_run_code_prints_and_makes_charts(tmp_path, cfg):
    code = "totals = df.groupby('region')['revenue'].sum()\nprint(totals.round(2))\ntotals.plot(kind='bar')"
    result = run_code(code, cfg.sample_csv, tmp_path, fig_prefix="t")
    assert result.ok, result.error
    assert "North" in result.stdout
    assert len(result.figures) == 1 and Path(result.figures[0]).exists()


def test_run_code_reports_errors_and_restores_prior_variables(tmp_path, cfg):
    bad = run_code("print(df['no_such_column'].sum())", cfg.sample_csv, tmp_path)
    assert not bad.ok and "KeyError" in bad.error

    ok = run_code("print(round(total, 2))", cfg.sample_csv, tmp_path,
                  prior_code=["total = df['revenue'].sum()\nprint('hidden')"])
    assert ok.ok and "hidden" not in ok.stdout


def test_run_code_timeout(tmp_path, cfg):
    result = run_code("while True:\n    pass", cfg.sample_csv, tmp_path, timeout=2)
    assert not result.ok and "Timed out" in result.error


def test_extractors():
    assert extract_code("Here:\n```python\nprint(1)\n```") == "print(1)"
    assert extract_json('Sure! {"steps": ["a"]} done') == {"steps": ["a"]}
    assert extract_json("nope") is None


def test_agent_self_corrects_and_verifies(cfg):
    llm = ScriptedLLM([
        json.dumps({"steps": ["Total revenue by product"]}),           # plan
        "```python\nprint(df.groupby('prod')['revenue'].sum())\n```",    # buggy code (wrong column)
        "```python\nby_product = df.groupby('product')['revenue'].sum().sort_values()\n"
        "print(by_product.round(2))\n```",                               # fixed code
        json.dumps({"complete": True}),                                  # verify
        "Smart Watch earns the most revenue.",                           # final answer
    ])
    agent = DataAnalystAgent(llm, cfg.sample_csv, cfg)
    events = list(agent.run("Which product earns the most?"))
    kinds = [e.kind for e in events]

    assert kinds == ["plan", "code", "error", "code", "result", "verify", "answer"]
    assert "KeyError" in events[2].content
    assert "Smart Watch" in events[4].content
    assert events[-1].content == "Smart Watch earns the most revenue."
    assert "KeyError" in llm.prompts[2]  # the fix prompt received the real error


def test_agent_adds_step_when_verifier_finds_gap(cfg):
    llm = ScriptedLLM([
        json.dumps({"steps": ["count rows"]}),
        "```python\nprint(len(df))\n```",
        json.dumps({"complete": False, "next_step": "average rating"}),
        "```python\nprint(round(df['customer_rating'].mean(), 2))\n```",
        "Answer.",
    ])
    events = list(DataAnalystAgent(llm, cfg.sample_csv, cfg).run("rows and rating?"))
    assert [e.kind for e in events].count("result") == 2
    assert any(e.kind == "verify" and "gap" in e.title for e in events)
