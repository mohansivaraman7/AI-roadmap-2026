import sys
from pathlib import Path

import gradio as gr

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app  # noqa: E402
from data_analyst.llm import LLMError  # noqa: E402


def test_ui_builds():
    assert isinstance(app.build_ui(), gr.Blocks)


def test_sample_dataset_loads():
    path, preview, profile = app.use_sample()
    assert Path(path).exists()
    assert len(preview) == 50
    assert "revenue" in profile


def test_chat_shows_llm_errors(monkeypatch):
    def fail(*a, **k):
        raise LLMError("HF_TOKEN is not set.")
    monkeypatch.setattr(app.llm, "chat", fail)
    *_, (history, box) = list(app.chat("hello", [], str(app.settings.sample_csv)))
    assert "HF_TOKEN" in history[-1]["content"]
