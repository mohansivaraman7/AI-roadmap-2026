"""Guarded code execution: static AST checks + a separate, time-limited Python process.

The model's code never runs inside the web server process. It runs in a child process with a minimal
environment (no HF_TOKEN), a timeout, and an isolated working directory. Run the app in Docker for
OS-level isolation as well.
"""
import ast
import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

ALLOWED_MODULES = {"pandas", "numpy", "matplotlib", "math", "statistics", "datetime",
                   "collections", "itertools", "re", "json", "textwrap"}
BLOCKED_NAMES = {"open", "exec", "eval", "compile", "__import__", "input", "globals", "locals",
                 "vars", "breakpoint", "exit", "quit", "getattr", "setattr", "delattr", "memoryview"}
BLOCKED_ATTRS = {"system", "popen", "remove", "unlink", "rmdir", "rmtree", "to_pickle", "read_pickle",
                 "to_csv", "to_excel", "to_parquet", "to_sql", "read_sql", "to_json", "to_hdf",
                 "read_csv", "read_excel", "read_json", "read_html", "read_parquet"}
MAX_OUTPUT_CHARS = 4000
RUNNER = Path(__file__).with_name("_runner.py")


class UnsafeCodeError(ValueError):
    pass


@dataclass
class ExecResult:
    ok: bool
    stdout: str = ""
    error: str = ""
    figures: List[str] = field(default_factory=list)


def validate_code(code: str) -> None:
    """Raise UnsafeCodeError if the code uses anything outside the analysis allow-list."""
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise UnsafeCodeError(f"SyntaxError: {exc.msg} (line {exc.lineno})") from exc
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots = [alias.name.split(".")[0] for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            roots = [(node.module or "").split(".")[0]]
        else:
            roots = []
        for root in roots:
            if root not in ALLOWED_MODULES:
                raise UnsafeCodeError(f"Import of '{root}' is not allowed. Allowed: {sorted(ALLOWED_MODULES)}")
        if isinstance(node, ast.Name) and node.id in BLOCKED_NAMES:
            raise UnsafeCodeError(f"Use of '{node.id}' is not allowed.")
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__") or node.attr in BLOCKED_ATTRS:
                raise UnsafeCodeError(f"Attribute '{node.attr}' is not allowed (df is already loaded).")


def _truncate(text: str) -> str:
    text = text.strip()
    return text if len(text) <= MAX_OUTPUT_CHARS else text[:MAX_OUTPUT_CHARS] + "\n…[output truncated]"


def run_code(code: str, csv_path: Path, work_dir: Path, prior_code: List[str] = (),
             fig_prefix: str = "fig", timeout: int = 30) -> ExecResult:
    """Execute one analysis step. Earlier successful steps are replayed silently to restore variables."""
    try:
        validate_code(code)
    except UnsafeCodeError as exc:
        return ExecResult(ok=False, error=f"Blocked by safety check: {exc}")

    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    payload = work_dir / f"{fig_prefix}_payload.json"
    payload.write_text(json.dumps({
        "csv_path": str(Path(csv_path).resolve()), "code": code, "prior_code": list(prior_code),
        "out_dir": str(work_dir.resolve()), "fig_prefix": fig_prefix}), encoding="utf-8")

    env = {"PATH": os.environ.get("PATH", ""), "HOME": str(work_dir), "MPLCONFIGDIR": str(work_dir),
           "PYTHONIOENCODING": "utf-8", "MPLBACKEND": "Agg"}
    try:
        proc = subprocess.run([sys.executable, "-I", str(RUNNER), str(payload)], cwd=work_dir, env=env,
                              capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return ExecResult(ok=False, error=f"Timed out after {timeout}s. Use vectorised pandas, avoid loops.")
    finally:
        payload.unlink(missing_ok=True)

    figures = sorted(str(p) for p in work_dir.glob(f"{fig_prefix}_*.png"))
    if proc.returncode != 0:
        return ExecResult(ok=False, stdout=_truncate(proc.stdout), error=_truncate(proc.stderr), figures=figures)
    if not proc.stdout.strip() and not figures:
        return ExecResult(ok=False, error="The code ran but printed nothing. print() the result you computed.")
    return ExecResult(ok=True, stdout=_truncate(proc.stdout), figures=figures)
