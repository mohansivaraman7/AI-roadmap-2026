"""Agentic data analyst: PLAN → WRITE CODE → EXECUTE → SELF-CORRECT → VERIFY → ANSWER.

The agent decides its own steps, observes real execution results, repairs its own failing code,
and checks whether it actually answered the question before replying.
"""
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, List, Optional

import pandas as pd

from .config import Settings, settings as default_settings
from .sandbox import run_code

logger = logging.getLogger(__name__)

PLANNER_PROMPT = """You are a senior data analyst planning an analysis of a pandas DataFrame `df`.
Dataset profile:
{profile}

Conversation so far:
{history}

Question: {question}

Break the work into 1 to {max_steps} small, concrete analysis steps. Each step must be doable with
pandas/numpy/matplotlib in a few lines. Add a chart step only if a chart genuinely helps.
Reply with JSON only: {{"steps": ["step 1", "step 2"]}}"""

CODER_PROMPT = """Write Python code for ONE analysis step.
Rules:
- A pandas DataFrame named `df` is ALREADY loaded. Never read or write files.
- `pd`, `np` and `plt` (matplotlib.pyplot) are already imported.
- Variables created in earlier steps still exist: {variables}
- print() every result you compute (use .round(2); print DataFrames with .to_string()).
- For charts: one figure, plt.figure(figsize=(8, 4.5)), title, axis labels, plt.tight_layout().
- Allowed imports only: pandas, numpy, matplotlib, math, statistics, datetime, collections, re.

Dataset profile:
{profile}

Overall question: {question}
Earlier steps and their output:
{done}

Current step: {step}
Reply with a single ```python code block and nothing else."""

FIX_PROMPT = """Your code for the step "{step}" failed.

Code:
```python
{code}
```

Error:
{error}

Dataset profile:
{profile}

Find the root cause (wrong column name, dtype, missing values, etc.) and return a corrected version.
Reply with a single ```python code block and nothing else."""

VERIFY_PROMPT = """Question: {question}

Analysis results so far:
{done}

Do these results fully answer the question with concrete numbers? If something essential is missing,
describe ONE more analysis step to fill the gap.
Reply with JSON only: {{"complete": true}} or {{"complete": false, "next_step": "..."}}"""

ANSWER_PROMPT = """You are a data analyst reporting to a business user.
Question: {question}

Verified results from executed code:
{done}

Write the answer in Markdown:
- Start with a one-sentence direct answer.
- Then 2-5 bullet points with the key numbers (only numbers that appear in the results above).
- End with one practical recommendation or caveat.
Do not mention code, steps or tools. Never invent numbers."""


@dataclass
class AgentEvent:
    kind: str          # plan | code | result | error | fix | verify | answer | figure
    title: str
    content: str = ""
    figures: List[str] = field(default_factory=list)


@dataclass
class StepRecord:
    step: str
    code: str
    output: str


def extract_json(text: str) -> Optional[dict]:
    match = re.search(r"\{.*\}", text or "", re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None


def extract_code(text: str) -> str:
    blocks = re.findall(r"```(?:python|py)?\s*\n(.*?)```", text or "", re.DOTALL)
    if blocks:
        return max(blocks, key=len).strip()
    return (text or "").strip().strip("`").strip()


def profile_dataframe(df: pd.DataFrame, max_cols: int = 40) -> str:
    lines = [f"Rows: {len(df):,} | Columns: {df.shape[1]}", "Columns (dtype, missing, example):"]
    for col in df.columns[:max_cols]:
        sample = df[col].dropna().iloc[0] if df[col].notna().any() else "NA"
        lines.append(f"- {col} ({df[col].dtype}, {int(df[col].isna().sum())} missing, e.g. {str(sample)[:40]})")
    lines.append("First rows:\n" + df.head(3).to_string(max_colwidth=30))
    return "\n".join(lines)


def _history_text(history: List[dict], max_turns: int = 4) -> str:
    lines = [f"{m['role']}: {m['content'][:300]}" for m in history[-max_turns:]
             if isinstance(m.get("content"), str) and not (m.get("metadata") or {}).get("title")]
    return "\n".join(lines) or "(none)"


def _variables(code_blocks: List[str]) -> str:
    names = set()
    for code in code_blocks:
        names.update(re.findall(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=)", code, re.MULTILINE))
    return ", ".join(sorted(names)) or "(none yet)"


class DataAnalystAgent:
    def __init__(self, llm, csv_path: Path, cfg: Settings = default_settings):
        self.llm = llm
        self.cfg = cfg
        self.csv_path = Path(csv_path)
        self.df = pd.read_csv(self.csv_path)
        self.profile = profile_dataframe(self.df)

    def _ask(self, prompt: str, max_tokens: Optional[int] = None) -> str:
        return self.llm.chat([{"role": "user", "content": prompt}], max_tokens=max_tokens)

    def plan(self, question: str, history: List[dict]) -> List[str]:
        raw = self._ask(PLANNER_PROMPT.format(profile=self.profile, history=_history_text(history),
                                              question=question, max_steps=self.cfg.max_plan_steps), 400)
        steps = [str(s).strip() for s in (extract_json(raw) or {}).get("steps", []) if str(s).strip()]
        return steps[: self.cfg.max_plan_steps] or [question]

    @staticmethod
    def _done_text(records: List[StepRecord]) -> str:
        if not records:
            return "(none yet)"
        return "\n\n".join(f"Step {i}: {r.step}\nOutput:\n{r.output[:1500]}" for i, r in enumerate(records, 1))

    def _execute_step(self, step: str, question: str, records: List[StepRecord],
                      work_dir: Path, index: int) -> Iterator[AgentEvent]:
        prior = [r.code for r in records]
        code = extract_code(self._ask(CODER_PROMPT.format(
            variables=_variables(prior), profile=self.profile, question=question,
            done=self._done_text(records), step=step)))

        for attempt in range(self.cfg.max_fix_attempts + 1):
            label = "Code" if attempt == 0 else f"Fixed code (attempt {attempt})"
            yield AgentEvent("code", f"🧑‍💻 Step {index} · {label}", f"```python\n{code}\n```")
            result = run_code(code, self.csv_path, work_dir, prior, f"s{index}a{attempt}",
                              self.cfg.exec_timeout_sec)
            if result.ok:
                output = result.stdout or "(chart created)"
                records.append(StepRecord(step, code, output))
                yield AgentEvent("result", f"📤 Step {index} · Output", f"```text\n{output}\n```",
                                 result.figures)
                return
            yield AgentEvent("error", f"🛠️ Step {index} · Error → self-correcting",
                             f"```text\n{result.error}\n```")
            if attempt < self.cfg.max_fix_attempts:
                code = extract_code(self._ask(FIX_PROMPT.format(step=step, code=code, error=result.error,
                                                                profile=self.profile)))
        records.append(StepRecord(step, code, f"FAILED after retries: {result.error[:300]}"))

    def run(self, question: str, history: Optional[List[dict]] = None) -> Iterator[AgentEvent]:
        history = history or []
        work_dir = self.cfg.runs_dir / uuid.uuid4().hex[:12]
        records: List[StepRecord] = []
        figures: List[str] = []

        steps = self.plan(question, history)
        yield AgentEvent("plan", "🧭 Plan", "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1)))

        index = 0
        queue = list(steps)
        extra_rounds = 0
        while queue:
            index += 1
            for event in self._execute_step(queue.pop(0), question, records, work_dir, index):
                figures.extend(event.figures)
                yield event
            if not queue and extra_rounds < self.cfg.max_extra_rounds:
                verdict = extract_json(self._ask(VERIFY_PROMPT.format(
                    question=question, done=self._done_text(records)), 200)) or {"complete": True}
                if not verdict.get("complete", True) and verdict.get("next_step"):
                    extra_rounds += 1
                    queue.append(str(verdict["next_step"]))
                    yield AgentEvent("verify", "🔍 Self-check: gap found", f"Adding step: {verdict['next_step']}")
                else:
                    yield AgentEvent("verify", "🔍 Self-check", "Results answer the question. ✅")

        if not any(not r.output.startswith("FAILED") for r in records):
            yield AgentEvent("answer", "Answer", "I could not compute a reliable answer — every step failed. "
                             "Try rephrasing the question or check the column names in the preview.")
            return
        answer = self._ask(ANSWER_PROMPT.format(question=question, done=self._done_text(records)))
        yield AgentEvent("answer", "Answer", answer, figures)
