"""Central configuration. Every value can be overridden with an environment variable or a .env file."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    # Hugging Face
    hf_token: str = os.getenv("HF_TOKEN", "")
    llm_model: str = os.getenv("LLM_MODEL", "Qwen/Qwen2.5-Coder-32B-Instruct")
    llm_provider: str = os.getenv("LLM_PROVIDER", "")
    max_new_tokens: int = _int("MAX_NEW_TOKENS", 900)
    temperature: float = _float("TEMPERATURE", 0.1)

    # Agent loop limits
    max_plan_steps: int = _int("MAX_PLAN_STEPS", 4)
    max_fix_attempts: int = _int("MAX_FIX_ATTEMPTS", 2)
    max_extra_rounds: int = _int("MAX_EXTRA_ROUNDS", 1)
    exec_timeout_sec: int = _int("EXEC_TIMEOUT_SEC", 30)
    max_upload_mb: int = _int("MAX_UPLOAD_MB", 25)

    # Paths
    sample_csv: Path = BASE_DIR / "data" / "sample_sales_2025.csv"
    runs_dir: Path = Path(os.getenv("RUNS_DIR", BASE_DIR / "storage" / "runs"))

    # Server
    host: str = os.getenv("GRADIO_SERVER_NAME", "0.0.0.0")
    port: int = _int("GRADIO_SERVER_PORT", 7860)


settings = Settings()
