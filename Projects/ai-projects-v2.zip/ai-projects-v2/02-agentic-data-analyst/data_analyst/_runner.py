"""Child-process entry point used by sandbox.run_code. Not meant to be run by hand."""
import contextlib
import io
import json
import sys
import traceback

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


def main(payload_path: str) -> int:
    with open(payload_path, encoding="utf-8") as fh:
        payload = json.load(fh)
    pd.set_option("display.width", 140)
    pd.set_option("display.max_columns", 25)
    pd.set_option("display.max_rows", 60)
    namespace = {"pd": pd, "np": np, "plt": plt, "df": pd.read_csv(payload["csv_path"])}

    for snippet in payload["prior_code"]:  # silently restore variables from earlier steps
        with contextlib.redirect_stdout(io.StringIO()):
            try:
                exec(compile(snippet, "<previous_step>", "exec"), namespace)
            except Exception:
                pass
        plt.close("all")

    try:
        exec(compile(payload["code"], "<step>", "exec"), namespace)
    except Exception:
        lines = traceback.format_exc().splitlines()
        print("\n".join(lines[-6:]), file=sys.stderr)
        return 1

    for i, num in enumerate(plt.get_fignums()):
        plt.figure(num).savefig(f"{payload['out_dir']}/{payload['fig_prefix']}_{i}.png",
                                dpi=110, bbox_inches="tight")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
