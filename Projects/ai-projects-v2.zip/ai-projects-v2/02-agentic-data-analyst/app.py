"""Agentic Data Analyst — Gradio chat UI. Run: python app.py  → http://localhost:7860"""
import logging
import shutil
import uuid
from pathlib import Path

import gradio as gr
import pandas as pd

from data_analyst.agent import DataAnalystAgent, profile_dataframe
from data_analyst.config import settings
from data_analyst.llm import HFChatModel, LLMError

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("app")

settings.runs_dir.mkdir(parents=True, exist_ok=True)
llm = HFChatModel(settings.llm_model, settings.hf_token, settings.llm_provider,
                  settings.max_new_tokens, settings.temperature)


def load_dataset(path: str):
    df = pd.read_csv(path)
    return path, df.head(50), f"**{Path(path).name}**\n\n```text\n{profile_dataframe(df)}\n```"


def use_sample():
    return load_dataset(str(settings.sample_csv))


def upload_csv(file):
    if file is None:
        return use_sample()
    src = Path(file if isinstance(file, str) else file.name)
    if src.stat().st_size > settings.max_upload_mb * 1024 * 1024:
        raise gr.Error(f"File is larger than {settings.max_upload_mb} MB.")
    dest_dir = settings.runs_dir / "uploads"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"{uuid.uuid4().hex[:8]}_{src.name}"
    shutil.copy(src, dest)
    try:
        return load_dataset(str(dest))
    except Exception as exc:
        raise gr.Error(f"Could not read this CSV: {exc}")


def chat(message: str, history: list, csv_path: str):
    message = (message or "").strip()
    if not message:
        yield history, ""
        return
    prior = list(history)
    history = prior + [{"role": "user", "content": message}]
    yield history, ""
    try:
        agent = DataAnalystAgent(llm, Path(csv_path or settings.sample_csv))
        for event in agent.run(message, prior):
            if event.kind == "answer":
                history.append({"role": "assistant", "content": event.content})
            else:
                history.append({"role": "assistant", "content": event.content,
                                "metadata": {"title": event.title, "status": "done"}})
                for fig in event.figures:
                    history.append({"role": "assistant", "content": {"path": fig}})
            yield history, ""
    except LLMError as exc:
        history.append({"role": "assistant", "content": f"⚠️ {exc}"})
        yield history, ""
    except Exception as exc:
        logger.exception("Agent run failed")
        history.append({"role": "assistant", "content": f"⚠️ Something went wrong: {exc}"})
        yield history, ""


def build_ui() -> gr.Blocks:
    with gr.Blocks(title="Agentic Data Analyst", theme=gr.themes.Soft()) as demo:
        gr.Markdown("# 📊 Agentic Data Analyst\n"
                    "Ask a question about a CSV. The agent **plans** the analysis, **writes and runs** pandas code, "
                    "**fixes its own errors**, **checks** that the question is answered, then reports back. "
                    "Expand the grey steps to see its work.")
        csv_state = gr.State(str(settings.sample_csv))
        with gr.Row():
            with gr.Column(scale=1, min_width=320):
                upload = gr.File(label="Upload CSV", file_types=[".csv"])
                sample_btn = gr.Button("📁 Use sample sales dataset")
                profile = gr.Markdown()
            with gr.Column(scale=2):
                chatbot = gr.Chatbot(type="messages", height=600, label="Analyst", show_copy_button=True)
                with gr.Row():
                    question = gr.Textbox(placeholder="e.g. Which region grew fastest in Q4?", scale=5,
                                          show_label=False, autofocus=True)
                    send = gr.Button("Analyse", variant="primary", scale=1)
                gr.Examples(["Which product earns the most revenue, and what is its share of total?",
                             "Plot monthly revenue for 2025 and explain the trend.",
                             "Do discounts increase units sold? Compare average units by discount level.",
                             "Which product has the lowest customer rating and in which region is it worst?"],
                            inputs=question)
                gr.ClearButton([chatbot, question], value="🧹 New chat")
        preview = gr.Dataframe(label="Data preview (first 50 rows)", interactive=False, wrap=True)

        demo.load(use_sample, None, [csv_state, preview, profile])
        sample_btn.click(use_sample, None, [csv_state, preview, profile])
        upload.upload(upload_csv, upload, [csv_state, preview, profile])
        send.click(chat, [question, chatbot, csv_state], [chatbot, question])
        question.submit(chat, [question, chatbot, csv_state], [chatbot, question])
    return demo


if __name__ == "__main__":
    build_ui().queue(default_concurrency_limit=4).launch(
        server_name=settings.host, server_port=settings.port, allowed_paths=[str(settings.runs_dir)])
