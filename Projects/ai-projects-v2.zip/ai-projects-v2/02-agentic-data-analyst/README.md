# 📊 Project 2 — Agentic Data Analyst (Agentic AI)

Ask a business question about any CSV. The AI does not just answer from text — it **works autonomously in a
loop**: it plans, writes pandas code, runs it, reads the real output, fixes its own bugs, checks whether the
question is really answered, and only then reports with charts.

## The agentic loop

```
           ┌────────────── PLAN (1–4 steps, JSON) ◄── dataset profile + question + chat history
           ▼
   for each step:  WRITE CODE → SAFETY CHECK (AST) → EXECUTE (separate process, timeout)
                        ▲                                   │
                        └── FIX CODE using the real error ◄─┘ (up to MAX_FIX_ATTEMPTS)
           ▼
   VERIFY: "do the results fully answer the question?" ── no → add one more step (MAX_EXTRA_ROUNDS)
           ▼
   ANSWER: business summary that uses only numbers produced by executed code
```

Every stage is visible in the chat as an expandable step (🧭 plan, 🧑‍💻 code, 📤 output, 🛠️ error → fix,
🔍 self-check), with charts shown inline.

**Agentic AI vs a plain chatbot:** the model chooses its own actions, observes the environment (Python
output), recovers from failure, and judges its own completion — that is what this project demonstrates.

Sample data: `data/sample_sales_2025.csv` — ~2,000 synthetic orders (region, product, channel, discount,
revenue, rating, with seasonality and a few missing ratings for the agent to handle).

## Safety

Model-written code is checked against an allow-list (pandas, numpy, matplotlib, math…; no `open`, `eval`,
`os`, file reads/writes, dunder access) and runs in a **separate Python process** with a timeout, a scratch
folder and no environment secrets (your `HF_TOKEN` is not passed to it). Docker adds OS isolation. This is a
teaching-grade guardrail, not a hardened sandbox — do not expose it to untrusted public users.

## Project layout

```
app.py                       Gradio UI (entry point)
data_analyst/config.py       All settings (env / .env)
data_analyst/llm.py          Hugging Face chat client with retries
data_analyst/agent.py        Planner, coder, fixer, verifier, reporter
data_analyst/sandbox.py      AST safety check + subprocess execution
data_analyst/_runner.py      Child process that executes one step
tests/                       Offline tests (scripted LLM, real sandbox execution)
```

## Run in PyCharm

1. **File → Open** this folder, create a Virtualenv interpreter (Python 3.10–3.12).
2. Terminal: `pip install -r requirements-dev.txt`
3. Copy `.env.example` to `.env`, set `HF_TOKEN`.
4. Right-click `app.py` → **Run** → http://localhost:7860
5. Right-click `tests` → **Run 'pytest in tests'**.

## Docker

```bash
docker build -t agentic-data-analyst .
docker run -p 7862:7860 --env-file .env agentic-data-analyst
```

## Jenkins

Same pipeline as the other projects: lint → tests → build → smoke test → optional push / deploy
(default deploy port 7862).

## Settings

| Variable | Default | Effect |
|---|---|---|
| `LLM_MODEL` | `Qwen/Qwen2.5-Coder-32B-Instruct` | A code-strong model makes far fewer fix loops |
| `MAX_PLAN_STEPS` | 4 | Upper bound on planned steps |
| `MAX_FIX_ATTEMPTS` | 2 | Self-correction attempts per step |
| `MAX_EXTRA_ROUNDS` | 1 | Extra steps the verifier may add |
| `EXEC_TIMEOUT_SEC` | 30 | Kill runaway code |
