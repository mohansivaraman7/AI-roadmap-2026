"""Pydantic request/response schemas for the Predictive Maintenance API."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator

from src.config import ROLLING_WINDOW_HOURS


class SensorSnapshot(BaseModel):
    """One hourly sensor reading."""
    timestamp: Optional[datetime] = Field(
        default=None, description="Reading timestamp (optional, for logging only)."
    )
    temperature_c: float = Field(..., description="Bearing/housing temperature in Celsius.")
    vibration_mm_s: float = Field(..., ge=0, description="Vibration velocity, mm/s RMS.")
    pressure_bar: float = Field(..., ge=0, description="Hydraulic/system pressure, bar.")
    rotation_speed_rpm: float = Field(..., ge=0, description="Shaft rotation speed, RPM.")
    current_draw_a: float = Field(..., ge=0, description="Motor current draw, Amps.")


class PredictionRequest(BaseModel):
    machine_id: str = Field(..., examples=["M0007"])
    machine_age_hours: float = Field(..., ge=0, description="Total operating hours since install.")
    hours_since_maintenance: float = Field(..., ge=0, description="Hours since last maintenance event.")
    readings: List[SensorSnapshot] = Field(
        ...,
        description=(
            f"The most recent {ROLLING_WINDOW_HOURS} hourly sensor readings, "
            "oldest first, most recent (current) reading last."
        ),
    )

    @field_validator("readings")
    @classmethod
    def validate_window_length(cls, v):
        if len(v) != ROLLING_WINDOW_HOURS:
            raise ValueError(
                f"'readings' must contain exactly {ROLLING_WINDOW_HOURS} hourly snapshots "
                f"(got {len(v)}). The model needs a full rolling window to compute trend features."
            )
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "machine_id": "M0007",
                "machine_age_hours": 8200.5,
                "hours_since_maintenance": 340,
                "readings": [
                    {
                        "temperature_c": 76.1 + i * 0.05,
                        "vibration_mm_s": 2.3 + i * 0.02,
                        "pressure_bar": 5.4,
                        "rotation_speed_rpm": 1795,
                        "current_draw_a": 14.2,
                    }
                    for i in range(ROLLING_WINDOW_HOURS)
                ],
            }
        }
    }


class ContributingFactor(BaseModel):
    feature: str
    value: float
    shap_contribution: float
    direction: str


class PredictionResponse(BaseModel):
    machine_id: str
    failure_probability: float
    risk_level: str
    recommended_action: str
    top_contributing_factors: List[ContributingFactor]
    model_version: str
    scored_at: datetime


class BatchPredictionRequest(BaseModel):
    requests: List[PredictionRequest]


class BatchPredictionResponse(BaseModel):
    results: List[PredictionResponse]


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_version: Optional[str] = None


class ModelInfoResponse(BaseModel):
    model_version: str
    algorithm: str
    trained_at: str
    feature_columns: List[str]
    test_set_metrics: dict
    top_features_by_mean_abs_shap: List[list]
    training_rows: int
    validation_rows: int
    test_rows: int


class MetricsResponse(BaseModel):
    total_predictions_served: int
    risk_level_counts: dict
    average_failure_probability: Optional[float]
