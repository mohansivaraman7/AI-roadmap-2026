"""
Predictive Maintenance API — serves failure-risk predictions from the
trained XGBoost model.

Run locally:
    uvicorn api.main:app --reload --port 8000

Then open http://localhost:8000/docs for interactive Swagger UI.
"""

import csv
import threading
from collections import Counter
from contextlib import asynccontextmanager
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from api.schemas import (
    BatchPredictionRequest,
    BatchPredictionResponse,
    HealthResponse,
    MetricsResponse,
    ModelInfoResponse,
    PredictionRequest,
    PredictionResponse,
)
from src.config import PREDICTION_LOG_PATH, SENSOR_COLUMNS
from src.model import ModelNotLoadedError, model_service

# --- lightweight in-memory + file-backed prediction logging -----------------
# In a real deployment this would write to a message queue / feature store /
# monitoring DB (e.g. for drift detection). Here it's a simple append-only
# log so the /metrics endpoint has something real to report and the README
# can talk through how this would extend to production monitoring.
_log_lock = threading.Lock()
_prediction_counter = Counter()
_probability_sum = 0.0
_probability_count = 0


def _log_prediction(response: PredictionResponse):
    global _probability_sum, _probability_count
    with _log_lock:
        _prediction_counter[response.risk_level] += 1
        _probability_sum += response.failure_probability
        _probability_count += 1

        PREDICTION_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        write_header = not PREDICTION_LOG_PATH.exists()
        with open(PREDICTION_LOG_PATH, "a", newline="") as f:
            writer = csv.writer(f)
            if write_header:
                writer.writerow(["scored_at", "machine_id", "failure_probability", "risk_level"])
            writer.writerow([
                response.scored_at.isoformat(),
                response.machine_id,
                response.failure_probability,
                response.risk_level,
            ])


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        model_service.load()
        print(f"Model loaded: version={model_service.metadata['model_version']}")
    except ModelNotLoadedError as e:
        # Server still starts so /health can report the problem clearly,
        # rather than crashing with an opaque error.
        print(f"WARNING: {e}")
    yield


app = FastAPI(
    title="Predictive Maintenance API",
    description=(
        "Forecasts the probability that an industrial machine will fail "
        "within the next 24 hours, from a rolling window of sensor telemetry. "
        "Powered by an XGBoost classifier with SHAP-based explanations."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _readings_to_window_df(request: PredictionRequest) -> pd.DataFrame:
    rows = [r.model_dump() for r in request.readings]
    df = pd.DataFrame(rows)[SENSOR_COLUMNS]
    return df


def _score_request(request: PredictionRequest) -> PredictionResponse:
    if not model_service.is_loaded:
        raise HTTPException(status_code=503, detail="Model is not loaded on this server.")

    window_df = _readings_to_window_df(request)
    result = model_service.predict_one(
        window_df,
        machine_age_hours=request.machine_age_hours,
        hours_since_maintenance=request.hours_since_maintenance,
    )
    response = PredictionResponse(machine_id=request.machine_id, **result)
    _log_prediction(response)
    return response


@app.get("/health", response_model=HealthResponse, tags=["Operations"])
def health():
    return HealthResponse(
        status="ok" if model_service.is_loaded else "degraded",
        model_loaded=model_service.is_loaded,
        model_version=model_service.metadata["model_version"] if model_service.is_loaded else None,
    )


@app.get("/model/info", response_model=ModelInfoResponse, tags=["Operations"])
def model_info():
    if not model_service.is_loaded:
        raise HTTPException(status_code=503, detail="Model is not loaded on this server.")
    meta = model_service.metadata
    return ModelInfoResponse(
        model_version=meta["model_version"],
        algorithm=meta["algorithm"],
        trained_at=meta["trained_at"],
        feature_columns=meta["feature_columns"],
        test_set_metrics=meta["test_set_metrics"],
        top_features_by_mean_abs_shap=meta["top_features_by_mean_abs_shap"],
        training_rows=meta["training_rows"],
        validation_rows=meta["validation_rows"],
        test_rows=meta["test_rows"],
    )


@app.get("/metrics", response_model=MetricsResponse, tags=["Operations"])
def metrics():
    with _log_lock:
        avg = (_probability_sum / _probability_count) if _probability_count else None
        return MetricsResponse(
            total_predictions_served=_probability_count,
            risk_level_counts=dict(_prediction_counter),
            average_failure_probability=avg,
        )


@app.post("/predict", response_model=PredictionResponse, tags=["Predictions"])
def predict(request: PredictionRequest):
    """Score a single machine's current sensor window for near-term failure risk."""
    return _score_request(request)


@app.post("/predict/batch", response_model=BatchPredictionResponse, tags=["Predictions"])
def predict_batch(request: BatchPredictionRequest):
    """Score multiple machines in one call (e.g. a full fleet sweep)."""
    results = [_score_request(r) for r in request.requests]
    return BatchPredictionResponse(results=results)


@app.get("/", tags=["Operations"])
def root():
    return {
        "service": "Predictive Maintenance API",
        "docs": "/docs",
        "health": "/health",
    }
