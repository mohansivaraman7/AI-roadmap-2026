"""
Synthetic sensor telemetry generator for the Predictive Maintenance project.

Simulates a fleet of industrial machines (think CNC machines, pumps, or
turbines) reporting hourly sensor readings. Each machine has its own
baseline "signature" and occasionally enters a degradation phase before
failing. The degradation phase injects realistic drift + increased noise
into the sensor channels, which is what the model has to learn to detect
*before* the failure actually happens.

Label definition (this is the modeling target):
    failure_within_24h = 1 if the machine will experience a failure event
    in the next 24 hourly readings, else 0.

This mirrors a real predictive-maintenance framing: you're not just
detecting "is it broken now" (trivial), you're forecasting near-term risk
so a maintenance crew can be scheduled proactively.
"""

import numpy as np
import pandas as pd
from pathlib import Path

RNG_SEED = 42
N_MACHINES = 120
HOURS_PER_MACHINE = 24 * 45  # ~45 days of hourly telemetry per machine
OUTPUT_PATH = Path(__file__).parent / "sensor_data.csv"

SENSOR_BASELINES = {
    # sensor: (mean, std, degradation_drift_per_hour, degradation_noise_multiplier)
    "temperature_c": (75.0, 3.0, 0.35, 2.2),
    "vibration_mm_s": (2.2, 0.4, 0.06, 2.8),
    "pressure_bar": (5.5, 0.3, -0.02, 1.8),   # pressure tends to drop before failure
    "rotation_speed_rpm": (1800.0, 40.0, -3.5, 1.6),  # speed sags under load
    "current_draw_a": (14.0, 1.1, 0.18, 2.0),
}

MACHINE_TYPES = ["CNC_MILL", "HYDRAULIC_PUMP", "CONVEYOR_MOTOR", "TURBINE"]


def simulate_machine(machine_id: int, rng: np.random.Generator) -> pd.DataFrame:
    machine_type = MACHINE_TYPES[machine_id % len(MACHINE_TYPES)]
    # Each machine has a slightly different baseline (manufacturing variance)
    machine_offset = {s: rng.normal(0, v[1] * 0.3) for s, v in SENSOR_BASELINES.items()}
    install_age_hours = rng.uniform(0, 15000)  # machines already have some mileage

    n = HOURS_PER_MACHINE
    timestamps = pd.date_range("2024-01-01", periods=n, freq="h")

    readings = {s: np.zeros(n) for s in SENSOR_BASELINES}
    failure_event = np.zeros(n, dtype=int)
    hours_since_maintenance = np.zeros(n)

    # Decide on 0-3 failure events over the observation window
    n_failures = rng.choice([0, 1, 1, 2, 2, 3], p=[0.12, 0.28, 0.28, 0.18, 0.10, 0.04])
    # Failures need runway: pick times leaving room for a 40-120h degradation ramp
    possible_starts = np.arange(200, n - 10)
    failure_times = np.sort(
        rng.choice(possible_starts, size=n_failures, replace=False)
    ) if n_failures > 0 else np.array([], dtype=int)
    # enforce minimum spacing between failures (need maintenance recovery time)
    filtered = []
    last = -10_000
    for t in failure_times:
        if t - last > 300:
            filtered.append(t)
            last = t
    failure_times = np.array(filtered, dtype=int)

    last_maintenance_idx = 0
    degradation_ramp = {s: rng.integers(40, 130) for s in SENSOR_BASELINES}  # hours of pre-failure ramp, per sensor

    for i in range(n):
        for sensor, (mean, std, drift, noise_mult) in SENSOR_BASELINES.items():
            base = mean + machine_offset[sensor]
            value = rng.normal(base, std)
            readings[sensor][i] = value

        hours_since_maintenance[i] = i - last_maintenance_idx

        if i in failure_times:
            failure_event[i] = 1
            last_maintenance_idx = i  # maintenance resets the machine right after failure

    # Now inject the degradation ramps leading up to each failure
    for sensor, (mean, std, drift, noise_mult) in SENSOR_BASELINES.items():
        ramp_len = degradation_ramp[sensor]
        for t in failure_times:
            start = max(0, t - ramp_len)
            for i in range(start, t + 1):
                progress = (i - start) / max(1, (t - start))  # 0 -> 1 as we approach failure
                drift_amount = drift * progress * ramp_len * 0.5
                extra_noise = rng.normal(0, std * (noise_mult - 1.0) * progress)
                readings[sensor][i] += drift_amount + extra_noise

    df = pd.DataFrame(readings)
    df.insert(0, "timestamp", timestamps)
    df.insert(0, "machine_id", f"M{machine_id:04d}")
    df.insert(2, "machine_type", machine_type)
    df["machine_age_hours"] = install_age_hours + np.arange(n)
    df["hours_since_maintenance"] = hours_since_maintenance
    df["failure_event"] = failure_event

    # Build the forward-looking label: will a failure happen in the next 24h?
    failure_idx = set(np.where(failure_event == 1)[0].tolist())
    label = np.zeros(n, dtype=int)
    for i in range(n):
        window_end = min(n, i + 25)
        if any((f in failure_idx) and (i < f <= window_end - 1) for f in range(i + 1, window_end)):
            label[i] = 1
    df["failure_within_24h"] = label

    return df


def main():
    rng = np.random.default_rng(RNG_SEED)
    frames = [simulate_machine(m, rng) for m in range(N_MACHINES)]
    full = pd.concat(frames, ignore_index=True)
    full.to_csv(OUTPUT_PATH, index=False)

    pos_rate = full["failure_within_24h"].mean()
    print(f"Wrote {len(full):,} rows for {N_MACHINES} machines to {OUTPUT_PATH}")
    print(f"Positive class rate (failure_within_24h=1): {pos_rate:.4%}")
    print(f"Total failure events simulated: {int(full['failure_event'].sum())}")


if __name__ == "__main__":
    main()
