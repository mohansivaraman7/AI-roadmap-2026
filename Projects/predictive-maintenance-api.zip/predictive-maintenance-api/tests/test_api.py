"""
API tests using FastAPI's TestClient (backed by httpx).

Run with: pytest -v

Requires a trained model to already exist at models/model.joblib — run
`python -m src.train` first (see README).
"""

import numpy as np
import pytest
from fastapi.testclient import TestClient

from api.main import app
from src.config import ROLLING_WINDOW_HOURS


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def _stable_readings(n=ROLLING_WINDOW_HOURS):
    return [
        {
            "temperature_c": 75.0,
            "vibration_mm_s": 2.2,
            "pressure_bar": 5.5,
            "rotation_speed_rpm": 1800,
            "current_draw_a": 14.0,
        }
        for _ in range(n)
    ]


def _degrading_readings(n=ROLLING_WINDOW_HOURS):
    progress = np.linspace(0, 1, n)
    return [
        {
            "temperature_c": 76.0 + progress[i] * 25,
            "vibration_mm_s": 2.2 + progress[i] * 5,
            "pressure_bar": 5.5 - progress[i] * 1.2,
            "rotation_speed_rpm": 1800 - progress[i] * 250,
            "current_draw_a": 14.0 + progress[i] * 9,
        }
        for i in range(n)
    ]


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["model_loaded"] is True


def test_model_info(client):
    resp = client.get("/model/info")
    assert resp.status_code == 200
    body = resp.json()
    assert "test_set_metrics" in body
    assert body["algorithm"].startswith("XGBoost")


def test_predict_stable_machine_is_low_risk(client):
    payload = {
        "machine_id": "TEST_STABLE",
        "machine_age_hours": 5000,
        "hours_since_maintenance": 100,
        "readings": _stable_readings(),
    }
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["machine_id"] == "TEST_STABLE"
    assert 0.0 <= body["failure_probability"] <= 1.0
    assert body["risk_level"] == "low"
    assert len(body["top_contributing_factors"]) > 0


def test_predict_degrading_machine_is_flagged(client):
    payload = {
        "machine_id": "TEST_DEGRADING",
        "machine_age_hours": 12000,
        "hours_since_maintenance": 800,
        "readings": _degrading_readings(),
    }
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert body["risk_level"] in ("medium", "high")
    assert body["failure_probability"] > 0.2


def test_predict_rejects_wrong_window_length(client):
    payload = {
        "machine_id": "TEST_BAD_WINDOW",
        "machine_age_hours": 1000,
        "hours_since_maintenance": 50,
        "readings": _stable_readings(n=10),  # too short
    }
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 422


def test_predict_rejects_negative_sensor_value(client):
    readings = _stable_readings()
    readings[0]["vibration_mm_s"] = -5.0
    payload = {
        "machine_id": "TEST_BAD_VALUE",
        "machine_age_hours": 1000,
        "hours_since_maintenance": 50,
        "readings": readings,
    }
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 422


def test_batch_predict(client):
    single = {
        "machine_id": "TEST_BATCH_1",
        "machine_age_hours": 3000,
        "hours_since_maintenance": 60,
        "readings": _stable_readings(),
    }
    resp = client.post("/predict/batch", json={"requests": [single, {**single, "machine_id": "TEST_BATCH_2"}]})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body["results"]) == 2
    assert {r["machine_id"] for r in body["results"]} == {"TEST_BATCH_1", "TEST_BATCH_2"}


def test_metrics_endpoint_reflects_traffic(client):
    # generate at least one prediction so counters are non-zero
    client.post("/predict", json={
        "machine_id": "TEST_METRICS",
        "machine_age_hours": 1000,
        "hours_since_maintenance": 50,
        "readings": _stable_readings(),
    })
    resp = client.get("/metrics")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total_predictions_served"] >= 1
