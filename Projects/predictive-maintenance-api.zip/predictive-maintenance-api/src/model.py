"""
Model service: loads the trained XGBoost model + metadata once, and exposes
a clean predict() method that the API layer calls. Keeping this separate
from api/main.py means the model logic is testable without spinning up
FastAPI, and could be swapped for a different serving framework later
without touching the ML code.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

import joblib
import pandas as pd
import shap

from src.config import METADATA_PATH, MODEL_PATH, RISK_THRESHOLDS
from src.features import compute_window_features_single, feature_names


class ModelNotLoadedError(RuntimeError):
    pass


def risk_level_for(probability: float) -> str:
    if probability >= RISK_THRESHOLDS["high"]:
        return "high"
    if probability >= RISK_THRESHOLDS["medium"]:
        return "medium"
    return "low"


RECOMMENDATIONS = {
    "high": "Schedule immediate inspection within 24h. High confidence of near-term failure.",
    "medium": "Add to next maintenance window. Monitor sensor trend closely.",
    "low": "No action required. Continue routine monitoring.",
}


class ModelService:
    def __init__(self):
        self.model = None
        self.metadata = None
        self.explainer = None
        self.feature_cols = feature_names()

    def load(self):
        if not MODEL_PATH.exists():
            raise ModelNotLoadedError(
                f"No trained model found at {MODEL_PATH}. Run `python -m src.train` first."
            )
        self.model = joblib.load(MODEL_PATH)
        with open(METADATA_PATH) as f:
            self.metadata = json.load(f)
        # TreeExplainer is fast for XGBoost and safe to build once at startup.
        self.explainer = shap.TreeExplainer(self.model)
        return self

    @property
    def is_loaded(self) -> bool:
        return self.model is not None

    def predict_one(self, window_df: pd.DataFrame, machine_age_hours: float,
                     hours_since_maintenance: float, top_k_factors: int = 5) -> dict:
        if not self.is_loaded:
            raise ModelNotLoadedError("Model not loaded. Call .load() first.")

        feats = compute_window_features_single(window_df, machine_age_hours, hours_since_maintenance)
        X = pd.DataFrame([feats])[self.feature_cols]

        probability = float(self.model.predict_proba(X)[0, 1])
        level = risk_level_for(probability)

        shap_values = self.explainer.shap_values(X)[0]
        contributions = sorted(
            zip(self.feature_cols, shap_values.tolist(), X.iloc[0].tolist()),
            key=lambda t: abs(t[1]),
            reverse=True,
        )[:top_k_factors]

        top_factors = [
            {
                "feature": name,
                "value": round(value, 4),
                "shap_contribution": round(shap_val, 4),
                "direction": "increases_risk" if shap_val > 0 else "decreases_risk",
            }
            for name, shap_val, value in contributions
        ]

        return {
            "failure_probability": round(probability, 6),
            "risk_level": level,
            "recommended_action": RECOMMENDATIONS[level],
            "top_contributing_factors": top_factors,
            "model_version": self.metadata["model_version"],
            "scored_at": datetime.now(timezone.utc).isoformat(),
        }


# Module-level singleton used by the FastAPI app.
model_service = ModelService()
