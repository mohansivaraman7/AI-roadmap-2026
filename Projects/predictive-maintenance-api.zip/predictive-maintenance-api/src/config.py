"""Shared configuration constants for the predictive maintenance project."""

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_PATH = PROJECT_ROOT / "data" / "sensor_data.csv"
MODEL_PATH = PROJECT_ROOT / "models" / "model.joblib"
METADATA_PATH = PROJECT_ROOT / "models" / "metadata.json"
PREDICTION_LOG_PATH = PROJECT_ROOT / "logs" / "predictions.log"

SENSOR_COLUMNS = [
    "temperature_c",
    "vibration_mm_s",
    "pressure_bar",
    "rotation_speed_rpm",
    "current_draw_a",
]

# Rolling window (in hours) used to compute trend/volatility features.
# Must match between training and the API — mismatches here are the classic
# "train/serve skew" bug in ML systems, so we centralize it in one place.
ROLLING_WINDOW_HOURS = 24

STATIC_FEATURE_COLUMNS = [
    "machine_age_hours",
    "hours_since_maintenance",
]

TARGET_COLUMN = "failure_within_24h"
MACHINE_ID_COLUMN = "machine_id"
TIMESTAMP_COLUMN = "timestamp"

RISK_THRESHOLDS = {
    "high": 0.5,
    "medium": 0.2,
    # anything below "medium" threshold is "low"
}

MODEL_VERSION = "1.0.0"
