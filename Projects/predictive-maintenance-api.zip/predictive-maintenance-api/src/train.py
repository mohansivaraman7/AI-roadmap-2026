"""
Training pipeline for the predictive-maintenance XGBoost model.

Key design decisions (worth being able to talk through in an interview):

1. Split by machine_id, not randomly by row. Rows from the same machine are
   highly correlated in time; a random row-level split leaks information
   from a machine's future into its own training data. We hold out entire
   machines for validation/test instead.

2. Class imbalance (~2.3% positive) is handled with XGBoost's
   `scale_pos_weight` rather than resampling, so the model still sees the
   true data distribution and probability outputs stay interpretable.

3. Model selection optimizes PR-AUC (average precision), not accuracy or
   plain ROC-AUC, because with this level of imbalance accuracy is
   meaningless (predicting "no failure" always would give ~97.7% accuracy)
   and PR-AUC better reflects performance on the rare positive class.

4. SHAP is used for both a global feature-importance summary (saved as an
   image for the README / interview walkthrough) and to power per-prediction
   explanations returned by the live API.
"""

import json
import time
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit, RandomizedSearchCV

from src.config import (
    DATA_PATH,
    METADATA_PATH,
    MODEL_PATH,
    MODEL_VERSION,
    TARGET_COLUMN,
)
from src.features import engineer_features_training, feature_names

RANDOM_STATE = 42


def load_and_split():
    print("Loading raw telemetry...")
    df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])

    print("Engineering features (rolling window stats per machine)...")
    features = engineer_features_training(df)

    feat_cols = feature_names()
    X = features[feat_cols]
    y = features[TARGET_COLUMN]
    groups = features["machine_id"]

    # Split 1: hold out 20% of machines entirely for the final test set.
    gss1 = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=RANDOM_STATE)
    trainval_idx, test_idx = next(gss1.split(X, y, groups))

    # Split 2: from the remaining machines, hold out 20% for validation
    # (used for early stopping).
    gss2 = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=RANDOM_STATE)
    train_idx_rel, val_idx_rel = next(
        gss2.split(X.iloc[trainval_idx], y.iloc[trainval_idx], groups.iloc[trainval_idx])
    )
    train_idx = trainval_idx[train_idx_rel]
    val_idx = trainval_idx[val_idx_rel]

    splits = {
        "X_train": X.iloc[train_idx], "y_train": y.iloc[train_idx],
        "X_val": X.iloc[val_idx], "y_val": y.iloc[val_idx],
        "X_test": X.iloc[test_idx], "y_test": y.iloc[test_idx],
    }
    print(f"Train: {len(train_idx):,} rows ({groups.iloc[train_idx].nunique()} machines)")
    print(f"Val:   {len(val_idx):,} rows ({groups.iloc[val_idx].nunique()} machines)")
    print(f"Test:  {len(test_idx):,} rows ({groups.iloc[test_idx].nunique()} machines)")
    return splits, feat_cols


def tune_hyperparameters(X_train, y_train, scale_pos_weight):
    """Light randomized search — kept small so the whole pipeline runs in
    under a minute or two, but demonstrates a real tuning step rather than
    hand-picked defaults."""
    base_model = xgb.XGBClassifier(
        objective="binary:logistic",
        eval_metric="aucpr",
        scale_pos_weight=scale_pos_weight,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )

    param_distributions = {
        "n_estimators": [150, 250, 400],
        "max_depth": [3, 4, 5, 6],
        "learning_rate": [0.03, 0.05, 0.1],
        "subsample": [0.7, 0.85, 1.0],
        "colsample_bytree": [0.6, 0.8, 1.0],
        "min_child_weight": [1, 3, 5],
        "reg_lambda": [1.0, 2.0, 5.0],
    }

    search = RandomizedSearchCV(
        base_model,
        param_distributions=param_distributions,
        n_iter=15,
        scoring="average_precision",
        cv=3,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbose=1,
    )
    print("Running RandomizedSearchCV (15 candidates x 3-fold)...")
    t0 = time.time()
    search.fit(X_train, y_train)
    print(f"Search finished in {time.time() - t0:.1f}s. Best PR-AUC (CV): {search.best_score_:.4f}")
    print(f"Best params: {search.best_params_}")
    return search.best_params_


def evaluate(model, X_test, y_test) -> dict:
    proba = model.predict_proba(X_test)[:, 1]
    preds = (proba >= 0.5).astype(int)

    roc_auc = roc_auc_score(y_test, proba)
    pr_auc = average_precision_score(y_test, proba)
    f1 = f1_score(y_test, preds)
    cm = confusion_matrix(y_test, preds).tolist()
    report = classification_report(y_test, preds, output_dict=True)

    print("\n=== Test Set Evaluation ===")
    print(f"ROC-AUC: {roc_auc:.4f}")
    print(f"PR-AUC (Average Precision): {pr_auc:.4f}")
    print(f"F1 (threshold=0.5): {f1:.4f}")
    print("Confusion matrix [[TN, FP], [FN, TP]]:")
    print(np.array(cm))
    print(classification_report(y_test, preds))

    return {
        "roc_auc": roc_auc,
        "pr_auc": pr_auc,
        "f1_at_0.5": f1,
        "confusion_matrix": cm,
        "classification_report": report,
    }


def save_shap_summary(model, X_sample):
    print("Computing SHAP values for global feature importance...")
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_sample)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    shap.summary_plot(shap_values, X_sample, show=False, plot_size=(10, 8))
    out_path = MODEL_PATH.parent / "shap_summary.png"
    plt.tight_layout()
    plt.savefig(out_path, dpi=140)
    plt.close()
    print(f"Saved SHAP summary plot to {out_path}")

    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    importance = sorted(
        zip(X_sample.columns.tolist(), mean_abs_shap.tolist()),
        key=lambda t: t[1],
        reverse=True,
    )
    return importance


def main():
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)

    splits, feat_cols = load_and_split()
    X_train, y_train = splits["X_train"], splits["y_train"]
    X_val, y_val = splits["X_val"], splits["y_val"]
    X_test, y_test = splits["X_test"], splits["y_test"]

    scale_pos_weight = (y_train == 0).sum() / max(1, (y_train == 1).sum())
    print(f"\nscale_pos_weight = {scale_pos_weight:.2f} (class imbalance correction)")

    best_params = tune_hyperparameters(X_train, y_train, scale_pos_weight)

    print("\nTraining final model with early stopping on validation set...")
    final_model = xgb.XGBClassifier(
        objective="binary:logistic",
        eval_metric="aucpr",
        scale_pos_weight=scale_pos_weight,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        early_stopping_rounds=30,
        **best_params,
    )
    final_model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        verbose=False,
    )
    print(f"Best iteration: {final_model.best_iteration}")

    metrics = evaluate(final_model, X_test, y_test)

    sample_idx = X_test.sample(n=min(2000, len(X_test)), random_state=RANDOM_STATE).index
    feature_importance = save_shap_summary(final_model, X_test.loc[sample_idx])

    print("\nSaving model artifact...")
    joblib.dump(final_model, MODEL_PATH)

    metadata = {
        "model_version": MODEL_VERSION,
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "algorithm": "XGBoost (XGBClassifier)",
        "feature_columns": feat_cols,
        "best_hyperparameters": best_params,
        "best_iteration": int(final_model.best_iteration) if final_model.best_iteration is not None else None,
        "scale_pos_weight": float(scale_pos_weight),
        "test_set_metrics": {
            "roc_auc": metrics["roc_auc"],
            "pr_auc": metrics["pr_auc"],
            "f1_at_0.5": metrics["f1_at_0.5"],
            "confusion_matrix": metrics["confusion_matrix"],
        },
        "top_features_by_mean_abs_shap": feature_importance[:15],
        "training_rows": len(X_train),
        "validation_rows": len(X_val),
        "test_rows": len(X_test),
    }
    with open(METADATA_PATH, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"Saved metadata to {METADATA_PATH}")
    print("\nDone. Top 10 features by mean |SHAP value|:")
    for name, val in feature_importance[:10]:
        print(f"  {name:35s} {val:.4f}")


if __name__ == "__main__":
    main()
