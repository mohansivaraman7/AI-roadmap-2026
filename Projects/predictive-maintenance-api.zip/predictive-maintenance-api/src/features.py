"""
Feature engineering shared by both the training pipeline (src/train.py) and
the live API (api/main.py).

This is the single most important design decision in the project: if
training and serving compute features differently, you get silent
train/serve skew and a model that looks great offline but is wrong in
production. So both paths call the exact same functions here.

For every sensor we compute, over a trailing window of ROLLING_WINDOW_HOURS
readings:
    - last value            (current reading)
    - rolling mean / std / min / max
    - slope (linear trend across the window — is it getting worse?)
    - z-score of the current reading vs. the window's own mean/std
      (how anomalous is "right now" relative to recent history?)

Plus two static features: machine_age_hours and hours_since_maintenance.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.config import ROLLING_WINDOW_HOURS, SENSOR_COLUMNS, STATIC_FEATURE_COLUMNS


def _slope(values: np.ndarray) -> float:
    """Linear trend of a 1D window. Positive = rising, negative = falling."""
    if len(values) < 2 or np.all(values == values[0]):
        return 0.0
    x = np.arange(len(values), dtype=float)
    slope, _ = np.polyfit(x, values, 1)
    return float(slope)


def feature_names() -> list[str]:
    names = []
    for sensor in SENSOR_COLUMNS:
        names += [
            f"{sensor}_last",
            f"{sensor}_roll_mean",
            f"{sensor}_roll_std",
            f"{sensor}_roll_min",
            f"{sensor}_roll_max",
            f"{sensor}_roll_slope",
            f"{sensor}_zscore",
        ]
    names += list(STATIC_FEATURE_COLUMNS)
    return names


def compute_window_features_single(window_df: pd.DataFrame, machine_age_hours: float,
                                    hours_since_maintenance: float) -> dict:
    """
    Compute the feature row for ONE prediction, given a window of the most
    recent readings (a DataFrame with one column per sensor, oldest row
    first, last row = "now"). Used by the live API.
    """
    feats = {}
    for sensor in SENSOR_COLUMNS:
        values = window_df[sensor].to_numpy(dtype=float)
        last = values[-1]
        mean = float(np.mean(values))
        std = float(np.std(values, ddof=0))
        feats[f"{sensor}_last"] = float(last)
        feats[f"{sensor}_roll_mean"] = mean
        feats[f"{sensor}_roll_std"] = std
        feats[f"{sensor}_roll_min"] = float(np.min(values))
        feats[f"{sensor}_roll_max"] = float(np.max(values))
        feats[f"{sensor}_roll_slope"] = _slope(values)
        feats[f"{sensor}_zscore"] = float((last - mean) / std) if std > 1e-9 else 0.0

    feats["machine_age_hours"] = float(machine_age_hours)
    feats["hours_since_maintenance"] = float(hours_since_maintenance)
    return feats


def engineer_features_training(df: pd.DataFrame) -> pd.DataFrame:
    """
    Vectorized version of the same feature logic, applied per-machine across
    the full historical dataset for model training. Rows without a full
    window (the first ROLLING_WINDOW_HOURS-1 hours of each machine's history)
    are dropped, matching what the API guarantees (it always sends a full
    window).
    """
    df = df.sort_values(["machine_id", "timestamp"]).reset_index(drop=True)
    grouped = df.groupby("machine_id", group_keys=False)

    feature_frames = [df[["machine_id", "timestamp"]].copy()]

    for sensor in SENSOR_COLUMNS:
        roll = grouped[sensor].rolling(window=ROLLING_WINDOW_HOURS, min_periods=ROLLING_WINDOW_HOURS)
        mean = roll.mean().reset_index(level=0, drop=True)
        std = roll.std(ddof=0).reset_index(level=0, drop=True)
        min_ = roll.min().reset_index(level=0, drop=True)
        max_ = roll.max().reset_index(level=0, drop=True)
        slope = roll.apply(_slope, raw=True).reset_index(level=0, drop=True)

        feature_frames.append(pd.DataFrame({
            f"{sensor}_last": df[sensor],
            f"{sensor}_roll_mean": mean,
            f"{sensor}_roll_std": std,
            f"{sensor}_roll_min": min_,
            f"{sensor}_roll_max": max_,
            f"{sensor}_roll_slope": slope,
            f"{sensor}_zscore": ((df[sensor] - mean) / std.replace(0, np.nan)).fillna(0.0),
        }))

    features = pd.concat(feature_frames, axis=1)
    for col in STATIC_FEATURE_COLUMNS:
        features[col] = df[col]

    features["failure_within_24h"] = df["failure_within_24h"]
    features = features.dropna(subset=[f"{SENSOR_COLUMNS[0]}_roll_mean"]).reset_index(drop=True)
    return features
