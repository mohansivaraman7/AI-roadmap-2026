# Predictive Maintenance API

Forecasts the probability that an industrial machine will **fail within the
next 24 hours**, from a rolling window of sensor telemetry (temperature,
vibration, pressure, rotation speed, current draw). Built with **XGBoost**
and served through a **FastAPI** REST API with **SHAP-based explanations**
on every prediction.

This project is designed to be walked through end-to-end in an interview:
it covers realistic data simulation, correct time-series train/test
splitting, class-imbalance handling, hyperparameter tuning, model
explainability, and production-style API design (validation, batching,
health checks, basic monitoring, containerization).

## Why this use case

Unplanned downtime is one of the costliest problems in manufacturing,
energy, and logistics — a single unplanned failure on a production line can
cost far more than the maintenance visit that would have prevented it. The
standard industry pattern is a "predict failure N hours ahead" model fed by
IoT sensor streams, which is exactly what this project implements:

- **Input:** the last 24 hourly sensor readings from a machine, plus its
  age and time since last maintenance.
- **Output:** probability of failure in the next 24 hours, a risk tier
  (low / medium / high), a recommended action, and the top factors driving
  that specific prediction.
- **Business framing:** false negatives (missed failures) are expensive
  (unplanned downtime, safety risk); false positives (unnecessary
  inspections) are cheap by comparison. The model is tuned and evaluated
  with that asymmetry in mind (see "Why PR-AUC, not accuracy" below).

## Architecture

```
generate_data.py          synthetic multi-machine sensor telemetry
        |
        v
src/features.py    <----  shared feature engineering (training AND serving
        |                  call the exact same functions — no train/serve skew)
        v
src/train.py               time/machine-aware split -> tune -> train -> evaluate
        |                   -> SHAP importance -> save model.joblib + metadata.json
        v
src/model.py                loads model once, wraps predict + SHAP explanation
        |
        v
api/main.py (FastAPI)      /predict  /predict/batch  /health  /model/info  /metrics
```

## Key design decisions (talking points)

1. **Group-aware train/val/test split.** Rows from the same machine are
   highly correlated in time, so the split is done by `machine_id` (entire
   machines held out), not by random row — a random split would leak a
   machine's future into its own training data and produce an
   over-optimistic offline score that falls apart in production.

2. **Class imbalance via `scale_pos_weight`, not resampling.** Failures are
   ~2.3% of rows here (realistic for this domain). XGBoost's
   `scale_pos_weight` re-weights the loss so probabilities stay calibrated
   and interpretable, instead of distorting the class distribution with
   SMOTE/undersampling.

3. **Why PR-AUC, not accuracy.** Always predicting "no failure" would score
   ~97.7% accuracy here and be useless. Average Precision (PR-AUC) is used
   for model selection because it reflects performance specifically on the
   rare positive (failure) class, which is what actually matters.

4. **Shared feature engineering module.** `src/features.py` is imported by
   both the training pipeline and the live API. This is the single most
   common source of silent bugs in ML systems ("training and serving computed
   the feature slightly differently") — solving it architecturally, by
   having one source of truth, is the point.

5. **SHAP for interpretability.** Every `/predict` response includes the
   top contributing features (via `TreeExplainer`), so a maintenance
   engineer sees *why* a machine was flagged, not just a number. This is a
   real requirement in most industrial ML deployments (operators won't act
   on a black box).

6. **API validates the contract, not just types.** The `/predict` schema
   enforces exactly 24 hourly readings (Pydantic `field_validator`) and
   non-negative sensor values — the model is only valid for a full rolling
   window, so a malformed request fails fast with a clear 422 rather than
   silently producing a nonsense prediction.

## Results (current trained model)

| Metric | Value |
|---|---|
| ROC-AUC | 0.997 |
| PR-AUC (Average Precision) | 0.838 |
| F1 @ threshold 0.5 | 0.759 |
| Recall on failures | 0.98 (563/576 caught) |
| Precision on failures | 0.62 |

At the default 0.5 threshold the model catches 98% of true near-term
failures, at the cost of some false alarms (precision 0.62) — a reasonable
trade for this domain, and the threshold is easy to move (see
`src/config.py: RISK_THRESHOLDS`) if the cost balance differs for a given
fleet.

Top predictive features by mean |SHAP value|: average current draw, peak
vibration, average temperature, average rotation speed, and hours since
last maintenance — consistent with how real bearing/motor failures
typically present (rising current + vibration, sagging speed).

A full SHAP summary plot is saved to `models/shap_summary.png` after
training.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate     # optional but recommended
pip install -r requirements.txt

# 1. Generate synthetic telemetry (~130k rows across 120 simulated machines)
python data/generate_data.py

# 2. Train the model (tunes hyperparameters, evaluates, saves SHAP plot)
python -m src.train

# 3. Run the API
uvicorn api.main:app --reload --port 8000
# -> open http://localhost:8000/docs for interactive Swagger UI

# 4. In another terminal: run the demo (simulates a fleet of machines,
#    some healthy, some degrading, and shows the API correctly separating them)
python -m scripts.demo_client --url http://localhost:8000

# 5. Run the test suite
pytest -v
```

The repo ships with `data/sensor_data.csv` and a trained `models/model.joblib`
already generated, so steps 3–5 work immediately without re-running 1–2 —
but re-running them (with a different random seed in `data/generate_data.py`)
is a good way to show the pipeline is reproducible, not hardcoded.

## Example request

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "machine_id": "M0007",
    "machine_age_hours": 8200.5,
    "hours_since_maintenance": 340,
    "readings": [
      {"temperature_c": 76.0, "vibration_mm_s": 2.3, "pressure_bar": 5.4, "rotation_speed_rpm": 1795, "current_draw_a": 14.2},
      ... 23 more hourly readings ...
    ]
  }'
```

```json
{
  "machine_id": "M0007",
  "failure_probability": 0.9748,
  "risk_level": "high",
  "recommended_action": "Schedule immediate inspection within 24h. High confidence of near-term failure.",
  "top_contributing_factors": [
    {"feature": "current_draw_a_roll_mean", "value": 18.0, "shap_contribution": 1.1228, "direction": "increases_risk"},
    {"feature": "vibration_mm_s_roll_max", "value": 6.69, "shap_contribution": 0.6967, "direction": "increases_risk"}
  ],
  "model_version": "1.0.0",
  "scored_at": "2026-09-16T13:59:25Z"
}
```

## API reference

| Endpoint | Method | Purpose |
|---|---|---|
| `/predict` | POST | Score one machine's current 24h sensor window |
| `/predict/batch` | POST | Score multiple machines in one call (fleet sweep) |
| `/health` | GET | Liveness + whether the model loaded successfully |
| `/model/info` | GET | Model version, algorithm, offline metrics, top SHAP features |
| `/metrics` | GET | Basic operational counters: predictions served, risk-level distribution |
| `/docs` | GET | Interactive Swagger UI (auto-generated by FastAPI) |

## Docker

```bash
docker build -t predictive-maintenance-api .
docker run -p 8000:8000 predictive-maintenance-api
```

## Project structure

```
predictive-maintenance-api/
├── data/
│   ├── generate_data.py     # synthetic telemetry simulator
│   └── sensor_data.csv      # generated dataset (~130k rows)
├── src/
│   ├── config.py            # shared constants (paths, feature window, thresholds)
│   ├── features.py          # feature engineering (training AND serving)
│   ├── train.py             # training pipeline: split, tune, evaluate, SHAP, save
│   └── model.py             # model service: load model, predict + explain
├── api/
│   ├── main.py               # FastAPI app + routes
│   └── schemas.py             # Pydantic request/response models
├── models/
│   ├── model.joblib          # trained XGBoost model
│   ├── metadata.json         # metrics, hyperparameters, feature list
│   └── shap_summary.png      # global feature importance plot
├── scripts/
│   └── demo_client.py        # simulates a fleet for live demos
├── tests/
│   └── test_api.py           # pytest suite (8 tests) using FastAPI TestClient
├── requirements.txt
├── Dockerfile
└── README.md
```

## What I'd add for a production deployment

Worth mentioning proactively in an interview — these are deliberately out
of scope for a portfolio project but show awareness of what's next:

- **Model registry + versioned rollout** (e.g. MLflow) instead of a
  model file baked into the Docker image, with shadow/canary deployment
  for new model versions.
- **Data/prediction drift monitoring** — the `/metrics` endpoint and
  `logs/predictions.log` here are a stub for what would become a proper
  pipeline (e.g. comparing live feature distributions to training
  distributions, alerting on drift).
- **Feature store** to guarantee training/serving consistency at scale,
  rather than the shared-module approach used here (which works well for
  one team but not across many models/teams).
- **Async ingestion** from a real IoT message bus (Kafka/MQTT) feeding a
  streaming feature pipeline, instead of the client assembling the 24h
  window itself.
- **Retraining pipeline** triggered on a schedule or on detected drift,
  with automatic evaluation gates before promoting a new model.
