"""
Demo client that simulates a fleet monitoring system polling the API.

Great for a live interview demo: start the API (`uvicorn api.main:app`),
then run this script and narrate what's happening — it streams realistic
"healthy" and "degrading" machines and shows the API correctly separating
them by risk level, with SHAP-based explanations.

Usage:
    python scripts/demo_client.py --url http://localhost:8000
"""

import argparse
import time

import numpy as np
import requests

from src.config import ROLLING_WINDOW_HOURS


def make_stable_window(rng):
    return [
        {
            "temperature_c": float(rng.normal(75, 2)),
            "vibration_mm_s": float(rng.normal(2.2, 0.3)),
            "pressure_bar": float(rng.normal(5.5, 0.2)),
            "rotation_speed_rpm": float(rng.normal(1800, 30)),
            "current_draw_a": float(rng.normal(14.0, 0.8)),
        }
        for _ in range(ROLLING_WINDOW_HOURS)
    ]


def make_degrading_window(rng, severity: float):
    """severity in [0, 1]: how far into the degradation ramp this machine is."""
    progress = np.linspace(max(0, severity - 0.3), severity, ROLLING_WINDOW_HOURS)
    return [
        {
            "temperature_c": float(75 + p * 25 + rng.normal(0, 1.5)),
            "vibration_mm_s": float(2.2 + p * 5 + rng.normal(0, 0.3)),
            "pressure_bar": float(max(0.1, 5.5 - p * 1.3 + rng.normal(0, 0.1))),
            "rotation_speed_rpm": float(1800 - p * 260 + rng.normal(0, 15)),
            "current_draw_a": float(14.0 + p * 9 + rng.normal(0, 0.5)),
        }
        for p in progress
    ]


FLEET = [
    ("M0101", "healthy", None),
    ("M0102", "healthy", None),
    ("M0210", "early_warning", 0.28),
    ("M0355", "critical", 0.9),
    ("M0489", "healthy", None),
    ("M0512", "moderate_warning", 0.6),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://localhost:8000")
    parser.add_argument("--delay", type=float, default=0.6, help="Seconds between requests, for demo pacing.")
    args = parser.parse_args()

    rng = np.random.default_rng(7)

    print(f"Polling fleet health via {args.url} ...\n")
    resp = requests.get(f"{args.url}/health", timeout=5)
    print(f"Health check: {resp.json()}\n")

    for machine_id, condition, severity in FLEET:
        if condition == "healthy":
            readings = make_stable_window(rng)
        else:
            readings = make_degrading_window(rng, severity)

        payload = {
            "machine_id": machine_id,
            "machine_age_hours": float(rng.uniform(1000, 15000)),
            "hours_since_maintenance": float(rng.uniform(50, 1200)),
            "readings": readings,
        }

        r = requests.post(f"{args.url}/predict", json=payload, timeout=10)
        r.raise_for_status()
        result = r.json()

        print(f"[{machine_id}] simulated_condition={condition:16s} "
              f"-> risk={result['risk_level']:6s} "
              f"prob={result['failure_probability']:.4f}")
        print(f"    action: {result['recommended_action']}")
        top = result["top_contributing_factors"][0]
        print(f"    top factor: {top['feature']} ({top['direction']}, "
              f"shap={top['shap_contribution']})\n")

        time.sleep(args.delay)

    metrics = requests.get(f"{args.url}/metrics", timeout=5).json()
    print("Fleet sweep complete. Cumulative /metrics:")
    print(metrics)


if __name__ == "__main__":
    main()
